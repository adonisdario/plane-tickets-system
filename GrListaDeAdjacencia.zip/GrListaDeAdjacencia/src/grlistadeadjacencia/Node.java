package grlistadeadjacencia;

public class Node {
    private String vertice, antecessor;
    private Node next;

    public String getAntecessor() {
        return antecessor;
    }

    public void setAntecessor(String antecessor) {
        this.antecessor = antecessor;
    }

    public String getVertice() {
        return vertice;
    }

    public void setVertice(String vertice) {
        this.vertice = vertice;
    }

    public Node getNext() {
        return next;
    }

    public void setNext(Node next) {
        this.next = next;
    }
    
}
