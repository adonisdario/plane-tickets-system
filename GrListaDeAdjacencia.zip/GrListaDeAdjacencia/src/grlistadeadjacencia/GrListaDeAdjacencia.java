package grlistadeadjacencia;

public class GrListaDeAdjacencia {

    public static void main(String[] args) {
        int vertices, n, i, j;

        Lista[] grafo;
        ArquivoTexto arq = new ArquivoTexto();
        arq.openToRead("grafo");
        String[] texto2 = new String[10];
        n = arq.lerDados(texto2);
        vertices = Integer.parseInt(texto2[0]); //pega o número de vertices do grafo
        String letras[];
        grafo = new Lista[vertices];
        letras = new String[vertices + 1];

        for (i = 0; i < n; i++) { //percorrendo o arquivo
            j = 0;
            if (i > 0) {
                letras[i - 1] = "" + texto2[i].charAt(0);
                System.out.println("Vértice : " + letras[i - 1]);
                grafo[i - 1] = new Lista();
                grafo[i - 1].exibir(letras[i - 1]);
                try {
                    while (i > 0 && !Character.isSpaceChar(texto2[i].charAt(j))) {
                        if (!Character.isLetter(texto2[i].charAt(j))) {
                            grafo[i - 1].adicionar("" + texto2[i].charAt(j), "" + texto2[i].charAt(0));
                            grafo[i - 1].exibir(letras[i - 1]);
                        }
                        j = j + 2;
                    }
                } catch (StringIndexOutOfBoundsException e) {
                }
            }
        }
        System.out.println("\nGRAFO:");

        for (i = 0; i < grafo.length; i++) { //Constroi o desenho do Grafo
            grafo[i].exibir(letras[i]);
        }

        arq.closeReadFile();
//  Código de construção do grafo
//        arq.openToWrite("grafo");
//        g = new String[6];
//        g[0] = "5";
//        g[1] = "A 0 1 2 3";
//        g[2] = "B";
//        g[3] = "C 4";
//        g[4] = "D 2";
//        g[5] = "E";
//        arq.gravarDados(g);
//        arq.closeWriteFile();
//        arq.openToRead("grafo");
//        String[] texto2 = new String[10];
//        n = arq.lerDados(texto2);
//        for (int i = 0; i < n; i++) {
//            System.out.println(texto2[i]);
//        }
//        arq.closeReadFile();
//        return;

    }

}
