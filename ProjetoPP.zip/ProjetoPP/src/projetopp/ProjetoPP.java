package projetopp;

import pacoteVoos.ModuloVoos;
import pacotePassagens.ModuloPassagens;
import pacoteClientes.ModuloClientes;
import java.util.Scanner;
import pacotePassagens.ListaTextoPassagem;

public class ProjetoPP {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        ListaTextoPassagem ltp = new ListaTextoPassagem();
        ModuloVoos mv = new ModuloVoos();
        ModuloPassagens mp = new ModuloPassagens();
        String nome, valido = "", cpf, dataPartida, dataChegada, origem;
        String destino, codVoo, codPassagem;
        ModuloClientes mc = new ModuloClientes();
        Validacao validacao = new Validacao();
        int re, resp = -1, resp2 = -1;
        boolean v;

        mc.carregarListaClientes("Clientes");
        mv.carregarListaVoos("Voos");
        ltp.carregarListaPassagens("Passagens", mp, mc, mv);
        mv.efetivarVoos();
        mp.efetivarPassagens();

        do {
            do {
                v = false;
                menuPrincipal();
                try {
                    resp = in.nextInt();
                    in.nextLine();
                    v = true;
                } catch (java.util.InputMismatchException ex) {
                    System.err.println("Digite apenas Números\n");
                    in.nextLine();
                }
            } while (!v);
            System.out.println("");
            switch (resp) {
                case 1:
                    do {
                        do {
                            v = false;
                            menuClientes();
                            try {
                                resp2 = in.nextInt();
                                in.nextLine();
                                v = true;
                            } catch (java.util.InputMismatchException ex) {
                                System.err.println("Digite apenas Números\n");
                                in.nextLine();
                            }
                        } while (!v);
                        System.out.println("");
                        switch (resp2) {
                            case 1:
                                System.out.println("CADASTRAR CLIENTE ---");
                                do {
                                    System.out.print("Digite o CPF: ");
                                    cpf = in.nextLine();
                                    if (cpf.equals("SAIR")) {
                                        System.out.println("Saindo da opção.\n");
                                        break;
                                    }
                                    cpf = cpf.trim();
                                    re = validacao.validarCPF(cpf);
                                } while (re == 0);
                                if (cpf.equals("SAIR")) {
                                    break;
                                }
                                System.out.println("CPF Válido.");
                                do {
                                    re = 1;
                                    System.out.print("Digite o nome (sem caracteres especiais): ");
                                    nome = in.nextLine();
                                    if (nome.equals("SAIR")) {
                                        System.out.println("Saindo da opção.\n");
                                        break;
                                    }
                                    valido = validacao.validarNome(nome);
                                    if (valido.equals("INVALIDO")) {
                                        System.out.println("Nome inválido.");
                                        re = 0;
                                    }
                                } while (re == 0);
                                if (nome.equals("SAIR")) {
                                    break;
                                }
                                mc.cadastrarCliente(cpf, valido);
                                break;
                            case 2:
                                System.out.println("ALTERAR DADOS ---");
                                do {
                                    re = 1;
                                    System.out.print("Digite o CPF do cliente: ");
                                    cpf = in.nextLine();
                                    cpf = cpf.trim();
                                    if (cpf.equals("SAIR")) {
                                        System.out.println("Saindo da opção.\n");
                                        break;
                                    } else if (validacao.validarCPF(cpf) == 0) {
                                        re = 0;
                                    }
                                } while (re == 0);
                                if (cpf.equals("SAIR")) {
                                    break;
                                }
                                mc.alterarDados(cpf);
                                break;
                            case 3:
                                System.out.println("EXIBIR DADOS DO CLIENTE ---");
                                do {
                                    re = 1;
                                    System.out.print("Digite o CPF do cliente: ");
                                    cpf = in.nextLine();
                                    cpf = cpf.trim();
                                    if (cpf.equals("SAIR")) {
                                        System.out.println("Saindo da opção.\n");
                                        break;
                                    } else if (validacao.validarCPF(cpf) == 0) {
                                        re = 0;
                                    }
                                } while (re == 0);
                                if (cpf.equals("SAIR")) {
                                    break;
                                }
                                mc.exibirDadosCliente(cpf);
                                break;
                            case 4:
                                System.out.println("REMOVER CLIENTE ---");
                                do {
                                    re = 1;
                                    System.out.print("Digite o CPF do cliente: ");
                                    cpf = in.nextLine();
                                    cpf = cpf.trim();
                                    if (cpf.equals("SAIR")) {
                                        System.out.println("Saindo da opção.\n");
                                        break;
                                    } else if (validacao.validarCPF(cpf) == 0) {
                                        re = 0;
                                    }
                                } while (re == 0);
                                if (cpf.equals("SAIR")) {
                                    break;
                                }
                                mc.removerCliente(cpf, mp, ltp);
                                break;
                            case 5:
                                System.out.println("BUSCAR CLIENTE ---");
                                do {
                                    re = 1;
                                    System.out.print("Digite o CPF do cliente: ");
                                    cpf = in.nextLine();
                                    cpf = cpf.trim();
                                    if (cpf.equals("SAIR")) {
                                        System.out.println("Saindo da opção.\n");
                                        break;
                                    } else if (validacao.validarCPF(cpf) == 0) {
                                        re = 0;
                                    }
                                } while (re == 0);
                                if (cpf.equals("SAIR")) {
                                    break;
                                }
                                try {
                                    if (mc.buscarCliente(cpf) == null) {
                                        System.out.println("Cliente não existe.");
                                    } else {
                                        System.out.println(mc.buscarCliente(cpf).getData());
                                    }
                                    break;
                                } catch (NullPointerException e) {

                                }
                            case 6:
                                System.out.println("Voltando ao menu principal.\n");
                                break;
                            default:
                                System.out.println("Opção inválida.");
                        }
                    } while (resp2 != 6);
                    break;
                case 2:
                    do {
                        do {
                            v = false;
                            menuVoos();
                            try {
                                resp2 = in.nextInt();
                                in.nextLine();
                                v = true;
                            } catch (java.util.InputMismatchException ex) {
                                System.err.println("Digite apenas Números\n");
                                in.nextLine();
                            }
                        } while (!v);
                        System.out.println("");
                        switch (resp2) {
                            case 1:
                                System.out.println("CADASTRAR VÔO ---");
                                do {
                                    System.out.print("Digite os números do código do vôo: ");
                                    codVoo = in.nextLine();
                                    if (codVoo.equals("SAIR")) {
                                        System.out.println("Saindo da opção.\n");
                                        break;
                                    }
                                } while (validacao.validarVoo(codVoo) == 0);
                                if (codVoo.equals("SAIR")) {
                                    break;
                                }
                                mv.cadastrarVoo("BLA" + codVoo, validacao);
                                break;
                            case 2:
                                System.out.println("BUSCAR UM VÔO ---");
                                do {
                                    re = 1;
                                    System.out.print("Digite a Origem do Vôo (Capital/EF): ");
                                    origem = in.nextLine();
                                    if (origem.equals("SAIR")) {
                                        System.out.println("Saindo da opção.\n");
                                        break;
                                    }
                                    if (mv.origensDestinos(origem) == 0) {
                                        System.out.println("Cidade não está na lista.");
                                        re = 0;
                                    }
                                } while (re == 0);
                                if (origem.equals("SAIR")) {
                                    break;
                                }
                                do {
                                    System.out.print("Digite a data de Partida do vôo (dd/MM/yyyy): ");
                                    dataPartida = in.nextLine();
                                    if (dataPartida.equals("SAIR")) {
                                        System.out.println("Saindo da opção.\n");
                                        break;
                                    }
                                } while (validacao.validarData(dataPartida) == 0);
                                if (dataPartida.equals("SAIR")) {
                                    break;
                                }
                                do {
                                    re = 1;
                                    System.out.print("Digite o Destino do Vôo (Capital/EF): ");
                                    destino = in.nextLine();
                                    if (destino.equals("SAIR")) {
                                        System.out.println("Saindo da opção.\n");
                                        break;
                                    }
                                    if (mv.origensDestinos(destino) == 0) {
                                        System.out.println("Cidade não está na lista.");
                                        re = 0;
                                    }
                                } while (re == 0);
                                if (destino.equals("SAIR")) {
                                    break;
                                }
                                do {
                                    System.out.print("Digite a data de Chegada do vôo (dd/MM/yyyy): ");
                                    dataChegada = in.nextLine();
                                    if (dataChegada.equals("SAIR")) {
                                        System.out.println("Saindo da opção.\n");
                                        break;
                                    }
                                } while (validacao.validarData(dataChegada) == 0);
                                if (dataChegada.equals("SAIR")) {
                                    break;
                                }
                                mv.buscarVoo(origem, destino, dataPartida, dataChegada);
                                break;
                            case 3:
                                System.out.println("ALTERAR VALOR DA PASSAGEM ---");
                                do {
                                    System.out.print("Digite o código do vôo: ");
                                    codVoo = in.nextLine();
                                    if (codVoo.equals("SAIR")) {
                                        System.out.println("Saindo da opção.\n");
                                        break;
                                    }
                                } while (validacao.validarVoo(codVoo) == 0);
                                if (codVoo.equals("SAIR")) {
                                    break;
                                }
                                mv.alterarValorPassagem("BLA" + codVoo);
                                break;
                            case 4:
                                System.out.println("CANCELAR VÔO ---");
                                do {
                                    System.out.print("Digite os números do código do vôo: ");
                                    codVoo = in.nextLine();
                                    if (codVoo.equals("SAIR")) {
                                        System.out.println("Saindo da opção.\n");
                                        break;
                                    }
                                } while (validacao.validarVoo(codVoo) == 0);
                                if (codVoo.equals("SAIR")) {
                                    break;
                                }
                                mv.cancelarVoo("BLA" + codVoo);
                                break;
                            case 5:
                                System.out.println("CONSULTAR VÔO ---");
                                do {
                                    System.out.print("Digite os números do código do vôo: ");
                                    codVoo = in.nextLine();
                                    if (codVoo.equals("SAIR")) {
                                        System.out.println("Saindo da opção.\n");
                                        break;
                                    }
                                } while (validacao.validarVoo(codVoo) == 0);
                                if (codVoo.equals("SAIR")) {
                                    break;
                                }
                                try {
                                    System.out.println(mv.consultarVoo("BLA" + codVoo).getData());
                                    break;
                                } catch (NullPointerException e) {

                                }
                                break;
                            case 6:
                                System.out.println("Voltando ao menu principal.\n");
                                break;
                            default:
                                System.out.println("Opção inválida.");
                        }
                    } while (resp2 != 6);
                    break;
                case 3:
                    do {
                        do {
                            v = false;
                            menuPassagens();
                            try {
                                resp2 = in.nextInt();
                                in.nextLine();
                                v = true;
                            } catch (java.util.InputMismatchException ex) {
                                System.err.println("Digite apenas Números\n");
                                in.nextLine();
                            }
                        } while (!v);
                        System.out.println("");
                        switch (resp2) {
                            case 1:
                                System.out.println("VENDER UMA PASSAGEM ---");
                                do {
                                    System.out.print("Digite o CPF do Cliente: ");
                                    cpf = in.nextLine();
                                    if (cpf.equals("SAIR")) {
                                        System.out.println("Saindo da opção.\n");
                                        break;
                                    }
                                    cpf = cpf.trim();
                                    re = validacao.validarCPF(cpf);
                                } while (re == 0);
                                if (cpf.equals("SAIR")) {
                                    break;
                                }
                                do {
                                    System.out.print("Digite os números do código do vôo: ");
                                    codVoo = in.nextLine();
                                    codVoo = codVoo.trim();
                                    if (codVoo.equals("SAIR")) {
                                        System.out.println("Saindo da opção.\n");
                                        break;
                                    }
                                    if (mv.consultarVoo("BLA" + codVoo).getData().getStatus() == false) {
                                        System.out.println("Vôo já efetivado, não é possível comprar uma passagem para este vôo.");
                                        codVoo = "SAIR";
                                        break;
                                    }
                                } while (validacao.validarVoo(codVoo) == 0);
                                if (codVoo.equals("SAIR")) {
                                    break;
                                }
                                mp.venderPassagem(ltp, cpf, "BLA" + codVoo, mv, mc);
                                break;
                            case 2:
                                System.out.println("CONSULTAR PASSAGENS ATIVAS DO CLIENTE ---");
                                do {
                                    System.out.print("Digite o CPF do Cliente: ");
                                    cpf = in.nextLine();
                                    if (cpf.equals("SAIR")) {
                                        System.out.println("Saindo da opção.\n");
                                        break;
                                    }
                                    cpf = cpf.trim();
                                    re = validacao.validarCPF(cpf);
                                } while (re == 0);
                                if (cpf.equals("SAIR")) {
                                    break;
                                }
                                mp.consultarPassagensCliente(cpf, mc);
                                break;
                            case 3:
                                System.out.println("CONSULTAR HISTÓRICO DO CLIENTE ---");
                                do {
                                    System.out.print("Digite o CPF: ");
                                    cpf = in.nextLine();
                                    if (cpf.equals("SAIR")) {
                                        System.out.println("Saindo da opção.\n");
                                        break;
                                    }
                                    cpf = cpf.trim();
                                    re = validacao.validarCPF(cpf);
                                } while (re == 0);
                                if (cpf.equals("SAIR")) {
                                    break;
                                }
                                mp.consultarHistoricoCliente(cpf, mc);
                                break;
                            case 4:
                                System.out.println("CANCELAR PASSAGEM ---");
                                System.out.print("Digite o código da passagem: ");
                                codPassagem = in.nextLine();
                                if (codPassagem.equals("SAIR")) {
                                    System.out.println("Saindo da opção.\n");
                                    break;
                                }
                                mp.cancelarPassagem(codPassagem, ltp);
                                break;
                            case 5:
                                System.out.println("EXIBIR PASSAGEIROS DE UM VÔO ---");
                                do {
                                    System.out.print("Digite os números do código do vôo: ");
                                    codVoo = in.nextLine();
                                    if (codVoo.equals("SAIR")) {
                                        System.out.println("Saindo da opção.\n");
                                        break;
                                    }
                                } while (validacao.validarVoo(codVoo) == 0);
                                if (codVoo.equals("SAIR")) {
                                    break;
                                }
                                mp.consultarPassageiros("BLA" + codVoo, mv);
                                break;
                            case 6:
                                System.out.println("Voltando ao menu principal.\n");
                                break;
                            default:
                                System.out.println("Opção inválida.");
                        }
                    } while (resp2 != 6);
                    break;
                case 4:
                    break;
                default:
                    System.out.println("Opção Inválida.");
            }
        } while (resp != 4);
        mc.gravarListaClientes("Clientes"); // Criar e inserir a lista no arquivo
        mv.gravarListaVoos("Voos");
        ltp.gravarListaTexto("Passagens");
        System.out.println("SAINDO DO PROGRAMA\nArquivos fechados.");
    }

    public static void menuPrincipal() {
        System.out.println("\nBRASIL LINHAS AÉREAS\n====== MENU PRINCIPAL ======");
        System.out.println("1.Módulo Clientes | 2.Módulo Vôos | 3.Módulo Passagens | 4.Sair do programa.");
        System.out.print("Opção Escolhida: ");
    }

    public static void menuClientes() {
        System.out.println("\n------- MENU CLIENTES -------");
        System.out.println("1.Cadastrar um cliente | 2.Alterar dados de um cliente | 3.Exibir dados de um cliente\n"
                + "4.Remover um cliente do cadastro | 5.Buscar um cliente | 6.Sair do módulo.");
        System.out.print("Opção Escolhida: ");
    }

    public static void menuVoos() {
        System.out.println("\n------- MENU VÔOS -------");
        System.out.println("1.Cadastrar um vôo | 2.Buscar um vôo | 3.Alterar o valor de uma passagem\n"
                + "4.Cancelar um vôo | 5.Consultar um vôo | 6.Sair do módulo.");
        System.out.print("Opção Escolhida: ");
    }

    public static void menuPassagens() {
        System.out.println("\n------- MENU PASSAGENS -------");
        System.out.println("1.Vender uma passagem | 2.Consultar passagens ativas de um cliente | 3.Exibir o histórico "
                + "de passagens de um cliente\n"
                + "4.Cancelar a passagem de um cliente | 5.Exibir passageiros de um vôo | 6.Sair do módulo.");
        System.out.print("Opção Escolhida: ");
    }

}
