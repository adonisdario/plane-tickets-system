package projetopp;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class Validacao {

    public int validarCPF(String cpf) {
        int re, cont;
        re = 1;
        cont = 0;
        for (int i = 0; i < cpf.length(); i++) {
            if (Character.isDigit(cpf.charAt(i))) {
                switch (cpf.charAt(i)) {
                    case '1':
                        cont = cont + 1;
                        break;
                    case '2':
                        cont = cont + 2;
                        break;
                    case '3':
                        cont = cont + 3;
                        break;
                    case '4':
                        cont = cont + 4;
                        break;
                    case '5':
                        cont = cont + 5;
                        break;
                    case '6':
                        cont = cont + 6;
                        break;
                    case '7':
                        cont = cont + 7;
                        break;
                    case '8':
                        cont = cont + 8;
                        break;
                    case '9':
                        cont = cont + 9;
                        break;
                }
            } else {
                re = 0;
                break;
            }
        }
        if (cpf.length() != 11 || cont % 11 != 0 || cont == 0 || re != 1 || cpf.equals("11111111111")
                || cpf.equals("22222222222") || cpf.equals("33333333333") || cpf.equals("44444444444")
                || cpf.equals("55555555555") || cpf.equals("66666666666") || cpf.equals("77777777777")
                || cpf.equals("88888888888") || cpf.equals("99999999999")) {
            System.out.println("CPF inválido.");
            return 0;
        }
        return 1;
    }

    public String validarNome(String nome) {
        nome = nome.trim();
        while (nome.contains("  ")) {
            nome = nome.replaceAll("  ", " ");
        }
        for (int i = 0; i < nome.length(); i++) {
            if (Character.isAlphabetic(nome.charAt(i)) || nome.charAt(i) == ' ') {

            } else {
                return "INVALIDO";
            }
        }
        return nome;
    }

    public int validarVoo(String codVoo) {
        if (codVoo.length() != 4) {
            System.out.println("Código inválido.");
            return 0;
        }
        for (int i = 0; i < codVoo.length(); i++) {
            if (Character.isDigit(codVoo.charAt(i))) {

            } else {
                System.out.println("Código inválido.");
                return 0;
            }
        }
        return 1;
    }

    public int validarData(String data) {
        Date dataAtual = new Date();
        SimpleDateFormat sdfD = new SimpleDateFormat("dd/MM/yyyy");
        String dataFormatada = sdfD.format(dataAtual); //transforma data em string
        if (data.length() != 10) {
            return 0;
        }

        char d1 = data.charAt(0), d2 = data.charAt(1);
        String d = String.valueOf(d1) + String.valueOf(d2);
        char m1 = data.charAt(3), m2 = data.charAt(4);
        String m = String.valueOf(m1) + String.valueOf(m2);
        String diaValido = "31", mesValido = "12";

        if (d.compareTo(diaValido) <= 0 && m.compareTo(mesValido) <= 0
                && Character.isDigit(data.charAt(0)) && Character.isDigit(data.charAt(1))
                && Character.isDigit(data.charAt(3)) && Character.isDigit(data.charAt(4))
                && Character.isDigit(data.charAt(6)) && Character.isDigit(data.charAt(7))
                && Character.isDigit(data.charAt(8)) && Character.isDigit(data.charAt(9))
                && data.charAt(2) == '/' && data.charAt(5) == '/'
                && data.compareTo(dataFormatada) >= 0) {
            return 1;
        } else {
            return 0;
        }
    }

    public int validarHora(String hora, String data) {
        Date dataAtual = new Date();
        SimpleDateFormat sdfD = new SimpleDateFormat("dd/MM/yyyy");
        String dataFormatada = sdfD.format(dataAtual);
        Date horaAtual = Calendar.getInstance().getTime();
        SimpleDateFormat sdfH = new SimpleDateFormat("HH:mm");
        String horaFormatada = sdfH.format(horaAtual); //transforma hora em string
        if (hora.length() != 5) {
            return 0;
        }

        char h1 = hora.charAt(0), h2 = hora.charAt(1);
        String h = String.valueOf(h1) + String.valueOf(h2);
        char m1 = hora.charAt(3), m2 = hora.charAt(4);
        String m = String.valueOf(m1) + String.valueOf(m2);
        String horaValida = "24", minutoValido = "60";
        if (data.equals(dataFormatada)) {
            if (hora.charAt(2) == ':'
                    && Character.isDigit(hora.charAt(0))
                    && Character.isDigit(hora.charAt(1))
                    && h.compareTo(horaValida) <= 0
                    && Character.isDigit(hora.charAt(3))
                    && Character.isDigit(hora.charAt(4))
                    && m.compareTo(minutoValido) <= 0
                    && hora.compareTo(horaFormatada) >= 0) {
                return 1;
            } else {
                return 0;
            }
        } else {
            if (hora.charAt(2) == ':'
                    && Character.isDigit(hora.charAt(0))
                    && Character.isDigit(hora.charAt(1))
                    && h.compareTo(horaValida) <= 0
                    && Character.isDigit(hora.charAt(3))
                    && Character.isDigit(hora.charAt(4))
                    && m.compareTo(minutoValido) <= 0) {
                return 1;
            } else {
                return 0;
            }
        }
    }
}
