package pacoteClientes;

import java.util.Scanner;
import pacotePassagens.ListaTextoPassagem;
import pacotePassagens.ModuloPassagens;

public class ModuloClientes {

    private Node first, last;
    private int qtd;
    Scanner in = new Scanner(System.in);

    /* OBSERVAÇÃO !!!
        - O cadastro de clientes deve ser colocado em um arquivo. OK
        - Antes do cadastro, a lista deve ser reconstruída do arquivo. OK
        - Após o final do programa, a lista deverá ser gravada no arquivo. OK
     */
    public void cadastrarCliente(String cpf, String nome) { //Não podem existir 2 CPFs iguais. Ordenação alfabética
        /* OBSERVAÇÃO!!!
            - CPF deve conter somente 11 números. OK
            - O Nome deve conter somente letras e fazer uma função para o nome conter
        apenas um espaço. OK
            - O telfone deve conter no mínimo 10 números. OK
            - O email deve conter um @. OK
         */
        Node aux, aux2, novo;
        Cliente cliente;
        if (first == null) {
            cliente = camposCadastro(cpf, nome);
            if (cliente == null) {
                System.out.println("Saindo do cadastramento.");
                return;
            }
            novo = new Node(cliente);
            first = novo;
            last = novo;
            qtd = 1;
            System.out.println("Cliente cadastrado.");
        } else if (nome.compareToIgnoreCase(first.getData().getNome()) <= 0) {
            if (buscarCliente(cpf) != null) {
                System.out.println("CPF já cadastrado.");
            } else {
                cliente = camposCadastro(cpf, nome);
                if (cliente == null) {
                    System.out.println("Saindo do cadastramento.");
                    return;
                }
                novo = new Node(cliente);
                novo.setNext(first);
                first.setPrev(novo);
                first = novo;
                qtd++;
                System.out.println("Cliente cadastrado.");
            }
        } else if (nome.compareToIgnoreCase(last.getData().getNome()) >= 0) {
            if (buscarCliente(cpf) != null) {
                System.out.println("CPF já cadastrado.");
            } else {
                cliente = camposCadastro(cpf, nome);
                if (cliente == null) {
                    System.out.println("Saindo do cadastramento.");
                    return;
                }
                novo = new Node(cliente);
                last.setNext(novo);
                novo.setPrev(last);
                last = novo;
                qtd++;
                System.out.println("Cliente cadastrado.");
            }
        } else {
            aux = first.getNext();
            while (aux != null) {
                if (buscarCliente(cpf) != null) {
                    System.out.println("CPF já cadastrado.");
                    return;
                } else if (nome.compareToIgnoreCase(aux.getData().getNome()) < 0) {
                    cliente = camposCadastro(cpf, nome);
                    if (cliente == null) {
                        System.out.println("Saindo do cadastramento.");
                        return;
                    }
                    novo = new Node(cliente);
                    aux2 = aux.getPrev();
                    novo.setPrev(aux2);
                    novo.setNext(aux);
                    aux2.setNext(novo);
                    aux.setPrev(novo);
                    qtd++;
                    System.out.println("Cliente cadastrado.\n");
                    return;
                }
                aux = aux.getNext();
            }
        }
    } //OK

    private Cliente camposCadastro(String cpf, String nome) {
        String telefone, email;
        int cont, re = 0;
        Cliente cliente;

        cliente = new Cliente(cpf);
        cliente.setNome(nome);
        do {
            System.out.print("Digite o telefone com DDD: ");
            telefone = in.nextLine();
            if (telefone.equals("SAIR")) {
                return null;
            }
            for (int i = 0; i < telefone.length(); i++) {
                if (telefone.length() >= 10 && Character.isDigit(telefone.charAt(i))) {
                    re = 1;
                } else {
                    System.out.println("Telefone inválido.");
                    re = 0;
                }
            }
        } while (re == 0);
        do {
            cont = 0;
            System.out.print("Digite o email: ");
            email = in.nextLine();
            if (email.equals("SAIR")) {
                return null;
            }
            for (int i = 0; i < email.length(); i++) {
                if (email.charAt(i) == '@') {
                    cont = 1;
                }
            }
            if (cont != 1) {
                System.out.println("Email inválido.");
            }
        } while (cont != 1);
        cliente.setTelefone(telefone);
        cliente.setEmail(email);
        return cliente;
    } //OK

    public void alterarDados(String cpf) { //Altera ou o telfone ou o email.
        int resp = -1, cont = 0;
        boolean v;
        String nome, telefone, email;
        Node aux = first;

        while (aux != null) {
            if (cpf.equalsIgnoreCase(aux.getData().getCpf())) {
                do {
                    System.out.println(aux.getData());
                    do {
                        System.out.println("\nQual dado você quer alterar?");
                        System.out.println("1.Nome | 2.Telefone | 3.Email | 4.Sair");
                        System.out.print("Opção escolhida: ");
                        v = false;
                        try {
                            resp = in.nextInt();
                            in.nextLine();
                            v = true;
                        } catch (java.util.InputMismatchException ex) {
                            System.err.println("Digite apenas Números\n");
                            in.nextLine();
                        }
                    } while (!v);
                    switch (resp) {
                        case 1:
                            System.out.print("Digite o nome: ");
                            nome = in.nextLine();
                            nome = nome.trim();
                            while (nome.contains("  ")) {
                                nome = nome.replaceAll("  ", " ");
                            }
                            aux.getData().setNome(nome);
                            break;
                        case 2:
                            do {
                                System.out.print("Digite o telefone com DDD: ");
                                telefone = in.nextLine();
                                telefone = telefone.trim();
                                if (telefone.length() < 10) {
                                    System.out.println("Telefone inválido.");
                                }
                            } while (telefone.length() < 10);
                            aux.getData().setTelefone(telefone);
                            break;
                        case 3:
                            do {
                                cont = 0;
                                System.out.print("Digite o email: ");
                                email = in.nextLine();
                                email = email.trim();
                                for (int i = 0; i < email.length(); i++) {
                                    if (email.charAt(i) == '@') {
                                        cont++;
                                    }
                                }
                                if (cont != 1) {
                                    System.out.println("Email inválido.");
                                }
                            } while (cont != 1);
                            aux.getData().setEmail(email);
                            break;
                        case 4:
                            break;
                        default:
                            System.out.println("Opção inválida.\n");
                    }
                    if (resp != 4) {
                        System.out.println("Alteração feita.\n");
                    }
                } while (resp != 4);
                return;
            }
            aux = aux.getNext();
        }
        System.out.println("CPF não está cadastrado.");
    } //OK

    public void exibirDadosCliente(String cpf) { //Exibe os dados do cliente.
        Node aux = first;
        while (aux != null) {
            if (cpf.equalsIgnoreCase(aux.getData().getCpf())) {
                System.out.println(aux.getData());
                return;
            }
            aux = aux.getNext();
        }
        System.out.println("CPF não existe.");
    } //OK

    public void removerCliente(String cpf, ModuloPassagens mp, ListaTextoPassagem ltp) { //Remove o cliente da lista.
        /* OBSERVAÇÃO!!!
            - Só pode remover o cliente que não possui nenhuma reserva de vôo ativo. OK
            - Quando um cliente é removido, seu histórico de passagens é apagado. OK
         */
        Node aux = first, aux2;

        if (first == null) {
            System.out.println("Lista Vazia.");
            return;
        } else if (buscarCliente(cpf) == null) {
            System.out.println("Voltando ao menu da opção.");
            return;
        } else if (qtd == 1) {
            if (first.getData().getCpf().equals(cpf)) {
                if (mp.removerNode(first.getData()) == 1) {
                    first = null;
                    last = null;
                    qtd = 0;
                    ltp.removerPassagens(cpf);
                } else {
                    System.out.println("Operação não realizada.1");
                    return;
                }
            }
        } else if (first.getData().getCpf().equals(cpf)) {
            if (mp.removerNode(first.getData()) == 1) {
                first = first.getNext();
                first.setPrev(null);
                qtd--;
                ltp.removerPassagens(cpf);
            } else {
                System.out.println("Operação não realizada.2");
                return;
            }
        } else if (last.getData().getCpf().equals(cpf)) {
            if (mp.removerNode(first.getData()) == 1) {
                last = last.getPrev();
                last.setNext(null);
                qtd--;
                ltp.removerPassagens(cpf);
            } else {
                System.out.println("Operação não realizada.3");
                return;
            }
        } else {
            while (aux != null) {
                if (aux.getData().getCpf().equals(cpf)) {
                    if (mp.removerNode(aux.getData()) == 1) {
                        aux2 = aux.getPrev();
                        aux = aux.getNext();
                        aux2.setNext(aux);
                        aux.setPrev(aux2);
                        qtd--;
                        return;
                    }
                }
                aux = aux.getNext();
            }
        }
        System.out.println("Cliente removido do cadastro.");
    } //OK

    public Node buscarCliente(String cpf) { //Retorna a referência para o nó.
        Node aux = first;
        while (aux != null) {
            if (cpf.equalsIgnoreCase(aux.getData().getCpf())) {
                return aux;
            }
            aux = aux.getNext();
        }
        return null;
    } //OK

    public void reinserirListaClientes(Cliente c) {
        Node novo = new Node(c);

        if (this.first == null) {
            this.first = novo;
            this.last = novo;
            this.qtd = 1;
        } else {
            this.last.setNext(novo);
            novo.setPrev(this.last);
            this.last = novo;
            this.qtd++;
        }
    } //OK

    public void gravarListaClientes(String nomeArq) { // Da lista para o arquivo
        Node aux = this.first;

        if (this.first == null) {
            ArquivoObjetoCliente arq = new ArquivoObjetoCliente();
            arq.openToWrite(nomeArq);
            arq.gravarCliente(null);
            arq.closeWriteFile();
        } else {
            ArquivoObjetoCliente arq = new ArquivoObjetoCliente();
            arq.openToWrite(nomeArq);
            while (aux != null) {
                arq.gravarCliente(aux.getData());
                aux = aux.getNext();
            }
            arq.closeWriteFile();
        }
    } //OK

    public void carregarListaClientes(String nomeArq) { // Do arquivo para a lista
        ArquivoObjetoCliente arq = new ArquivoObjetoCliente();
        Cliente c;

        boolean exists = arq.openToRead(nomeArq);
        if (exists == true) {
            c = arq.lerCliente();
            while (c != null) {
                this.reinserirListaClientes(c);
                c = arq.lerCliente();
            }
            arq.closeReadFile();
            System.out.println("Arquivo Clientes aberto.");
        } else {
            arq.openToWrite("Clientes");
            arq.closeWriteFile();
            System.out.println("Arquivo Clientes criado.");
        }
    } //OK

}
