package pacotePassagens;

import java.io.Serializable;

public class PassagemTexto implements Serializable {
    private final String codigoReserva;
    private String codigoAssento, codVoo, cpf;
    private String status; //0 = Ativa, 1 = efetivada ou 2 = cancelada.
    
    public PassagemTexto(String codigoReserva) {
        this.codigoReserva = codigoReserva;
    }

    public String getCodigoAssento() {
        return codigoAssento;
    }

    public String getCodigoReserva() {
        return codigoReserva;
    }
    
    public void setCodigoAssento(String codigoAssento) {
        this.codigoAssento = codigoAssento;
    }

    public String getCodVoo() {
        return codVoo;
    }

    public void setCodVoo(String codVoo) {
        this.codVoo = codVoo;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
    
    @Override
    public String toString() {
        return "Passagem - " + "Código da Reserva: " + codigoReserva + ", Assento: " + codigoAssento + ", Status: " + status
                + "\nVoo( " + codVoo + ")\n Cliente(" + cpf + ")";
    }
}
