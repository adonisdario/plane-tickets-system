package pacotePassagens;

import pacoteClientes.ModuloClientes;
import pacoteVoos.ModuloVoos;

public class ListaTextoPassagem {

    boolean foi;
    private NodeT first, last;
    private int qtd;

    public void criarListaTexto(String codReserva, String cpf, String codVoo, String status, String codAssento) {
        NodeT novo;
        PassagemTexto pt;
        pt = new PassagemTexto(codReserva);
        pt.setCpf(cpf);
        pt.setCodVoo(codVoo);
        pt.setCodigoAssento(codAssento);
        pt.setStatus(status);
        novo = new NodeT(pt);

        if (first == null) {
            first = novo;
            last = novo;
            qtd = 1;
        } else if (codReserva.compareToIgnoreCase(first.getData().getCodigoReserva()) < 0) {
            novo.setNext(first);
            first.setPrev(novo);
            first = novo;
            qtd++;
        } else if (codReserva.compareToIgnoreCase(last.getData().getCodigoReserva()) > 0) {
            last.setNext(novo);
            novo.setPrev(last);
            last = novo;
            qtd++;
        } else {
            NodeT aux = first.getNext();
            while (aux != null) {
                if (codReserva.compareToIgnoreCase(aux.getData().getCodigoReserva()) < 0) {
                    NodeT aux2 = aux.getPrev();
                    novo.setPrev(aux2);
                    novo.setNext(aux);
                    aux2.setNext(novo);
                    aux.setPrev(novo);
                    qtd++;
                    return;
                }
                aux = aux.getNext();
            }
        }
    }

    public void reinserirPassagens(PassagemTexto p, ModuloPassagens mp, ModuloClientes mc, ModuloVoos mv) {
        NodeT novo = new NodeT(p);

        if (this.first == null) {
            this.first = novo;
            this.last = novo;
            this.qtd = 1;
        } else {
            this.last.setNext(novo);
            novo.setPrev(this.last);
            this.last = novo;
            this.qtd++;
        }
        mp.reinserirListaPassagens(p, mc, mv);
    }

    public void gravarListaTexto(String nomeArq) { // Da lista para o arquivo
        NodeT aux = this.first;

        if (this.first == null) {
            ArquivoObjetoPassagem arq = new ArquivoObjetoPassagem();
            arq.openToWrite(nomeArq);
            arq.gravarPassagem(null);
            arq.closeWriteFile();
        } else {
            ArquivoObjetoPassagem arq = new ArquivoObjetoPassagem();
            arq.openToWrite(nomeArq);
            while (aux != null) {
                arq.gravarPassagem(aux.getData());
                aux = aux.getNext();
            }
            arq.closeWriteFile();
        }
    }

    public void carregarListaPassagens(String nomeArq, ModuloPassagens mp, ModuloClientes mc, ModuloVoos mv) { // Do arquivo para a lista
        ArquivoObjetoPassagem arq = new ArquivoObjetoPassagem();
        PassagemTexto p;

        boolean exists = arq.openToRead(nomeArq);
        if (exists == true) {
            p = arq.lerPassagem();
            while (p != null) {
                this.reinserirPassagens(p, mp, mc, mv);
                p = arq.lerPassagem();
            }
            arq.closeReadFile();
            System.out.println("Arquivo Passagens aberto.\n");
        } else {
            arq.openToWrite("Passagens");
            arq.closeWriteFile();
            System.out.println("Arquivo Passagens criado.");
        }
    }

    public void removerPassagens(String cpf) {
        NodeT aux = first, aux2;

        if (first == null) {
            System.out.println("Lista Vazia.");
        } else if (qtd == 1) {
            if (first.getData().getCpf().equals(cpf)) {
                first = null;
                last = null;
                qtd = 0;
            } else {
                System.out.println("Cliente não existe.");
            }
        } else if (first.getData().getCpf().equals(cpf)) {
            first = first.getNext();
            first.setPrev(null);
            qtd--;
        } else if (last.getData().getCpf().equals(cpf)) {
            last = last.getPrev();
            last.setNext(null);
            qtd--;
        } else {
            while (aux != null) {
                if (aux.getData().getCpf().equals(cpf)) {
                    aux2 = aux.getPrev();
                    aux = aux.getNext();
                    aux2.setNext(aux);
                    aux.setPrev(aux2);
                    qtd--;
                }
                aux = aux.getNext();
            }
        }
    }
    
    public void alterarStatusPassagem(String codReserva) {
        NodeT aux = first;
        
        if (first == null) {
            System.out.println("Lista de paassagens vazia.;");
        } else {
            while (aux != null) {
                if (aux.getData().getCodigoReserva().equals(codReserva)) {
                    aux.getData().setStatus("Cancelada");
                    return;
                }
                aux = aux.getNext();
            }
            System.out.println("Código não existe.");
        }        
    }
}
