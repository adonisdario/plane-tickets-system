package pacotePassagens;

import pacoteVoos.Assento;
import pacoteClientes.ModuloClientes;
import pacoteClientes.Cliente;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Scanner;
import pacoteVoos.ModuloVoos;

public class ModuloPassagens { // Gravar em um arquivo de Strings

    Scanner in = new Scanner(System.in);
    private NodeP first, last;
    private int qtd;

    /* OBSERVAÇÃO!!!
        - É necessário validar todas as informações, como cpf, código do vôo, código da passagem... OK
        - Antes de vender passagens, é preciso reconstruir a lista do arquivo. OK
        - Alterar o status das passagens como efetivadas, para aquelas que estão com a
    data anterior a atual. OK
     */
    public void efetivarPassagens() {
        Date data = new Date();
        SimpleDateFormat sdfD = new SimpleDateFormat("dd/MM/yyyy");
        String dataFormatada = sdfD.format(data); //transforma data em string
        Date hora = Calendar.getInstance().getTime();
        SimpleDateFormat sdfH = new SimpleDateFormat("HH:mm");
        String horaFormatada = sdfH.format(hora); //transforma hora em string

        NodeP aux = first;
        
        if (first == null) {
            return;
        }
        while (aux != null) {
            Assento[][] mapa = aux.getData().getVoo().getMapa();
            if ((dataFormatada.compareTo(aux.getData().getVoo().getDataPartida()) > 0
                    || (dataFormatada.compareTo(aux.getData().getVoo().getDataPartida()) == 0
                    && horaFormatada.compareTo(aux.getData().getVoo().getHoraPartida()) >= 0))
                    && aux.getData().getVoo().getStatus() == true) {
                for (int i = 0; i < mapa.length; i++) {
                    for (int j = 0; j < mapa.length; j++) {
                        mapa[i][j].setDisponivel(true);
                    }
                }
                aux.getData().setStatus("Efetivado"); //Efetivado
                aux.getData().getVoo().setStatus(false);
            }
            aux = aux.getNext();
        }
    } //OK

    private Passagem camposPassagem(String cpf, String codVoo, ModuloVoos mv, ModuloClientes mc, ListaTextoPassagem ltp) {
        /* OBSERVAÇÃO!!!
            - Para realizar uma venda é necessário validar o CPF, o código
        do vôo e se no vôo existe assentos diponíveis. OK
            - O cliente pode apenas escolher um assento. OK
            - Efetuada a venda, é necessário atualizar o registro de vendas,
        o número de assentos disponíveis e gerar um código de reserva. OK
            - Deve-se gerar um documento contendo as informações da passagem
        e o valor dela. OK
            - Não pode existir duas passagens com o mesmo código. OK
            - O Código da passagem deve conter apenas letras e números. OK
            - No arquivo, deve conter o código da reserva, cpf do cliente, o código
        do vôo e o código do assento. OK
            - No final do programa, os dados deverão ser gravados em um arquivo. OK
         */
        Passagem passagem;
        String codAssento;
        String codReserva;
        
        if (mc.buscarCliente(cpf) == null) {
            System.out.println("Cliente não existe.");
            return null;
        } else if (mv.consultarVoo(codVoo) == null) {
            System.out.println("Não existe este vôo.");
            return null;
        } else if (mv.consultarVoo(codVoo).getData().getAssentosDisp() == 0) {
            System.out.println("Vôo cheio.");
            return null;
        } else {
            codAssento = mapaDeAssentos(codVoo, mv); //Escolhendo o assento
            if (codAssento.equals("SAIR")) {
                return null;
            }
            codReserva = gerarCodigoReserva(codVoo, codAssento, cpf); //Gerando código da reserva
            passagem = new Passagem(codReserva); //Criando a passagem
            passagem.setVoo(mv.consultarVoo(codVoo).getData()); //Definindo o vôo da passagem
            passagem.setCliente(mc.buscarCliente(cpf).getData()); //Definindo o cliente da passagem
            passagem.setCodigoAssento(codAssento); // Definindo o código do assento da passagem
            return passagem;
        }
    } //OK

    public void venderPassagem(ListaTextoPassagem ltp, String cpf, String codVoo, ModuloVoos mv, ModuloClientes mc) {
        Passagem passagem = camposPassagem(cpf, codVoo, mv, mc, ltp);
        if (passagem == null) {
            System.out.println("Saindo do cadastramento.");
            return;
        }
        NodeP aux, novo;
        if (first == null) {
            novo = new NodeP(passagem);
            first = novo;
            last = novo;
            qtd = 1;
            System.out.println("Passagem cadastrada.");
            System.out.println(novo.getData());
            ltp.criarListaTexto(novo.getData().getCodigoReserva(), cpf, codVoo, "Ativa", novo.getData().getCodigoAssento());
        } else if (passagem.getCodigoReserva().compareToIgnoreCase(first.getData().getCodigoReserva()) < 0) {
            if (passagem.getCodigoReserva().equalsIgnoreCase(first.getData().getCodigoReserva())) {
                System.out.println("Reserva com código já cadastrado.");
            } else {
                novo = new NodeP(passagem);
                novo.setNext(first);
                first.setPrev(novo);
                first = novo;
                qtd++;
                System.out.println("Passagem cadastrada.");
                System.out.println(novo.getData());
                ltp.criarListaTexto(passagem.getCodigoReserva(), cpf, codVoo, "Ativa", passagem.getCodigoAssento());
            }
        } else if (passagem.getCodigoReserva().compareToIgnoreCase(last.getData().getCodigoReserva()) > 0) {
            if (passagem.getCodigoReserva().equalsIgnoreCase(last.getData().getCodigoReserva())) {
                System.out.println("Código já cadastrado.");
            } else {
                novo = new NodeP(passagem);
                last.setNext(novo);
                novo.setPrev(last);
                last = novo;
                qtd++;
                System.out.println("Passagem cadastrado.");
                System.out.println(novo.getData());
                ltp.criarListaTexto(passagem.getCodigoReserva(), cpf, codVoo, "Ativa", passagem.getCodigoAssento());
            }
        } else {
            aux = first.getNext();
            while (aux != null) {
                if (passagem.getCodigoReserva().equalsIgnoreCase(aux.getData().getCodigoReserva())) {
                    System.out.println("Código de reserva já cadastrado.");
                    return;
                } else if (passagem.getCodigoReserva().compareToIgnoreCase(aux.getData().getCodigoReserva()) < 0) {
                    novo = new NodeP(passagem);
                    NodeP aux2 = aux.getPrev();
                    novo.setPrev(aux2);
                    novo.setNext(aux);
                    aux2.setNext(novo);
                    aux.setPrev(novo);
                    qtd++;
                    System.out.println("Passagem cadastrada.");
                    System.out.println(novo.getData());
                    ltp.criarListaTexto(passagem.getCodigoReserva(), cpf, codVoo, "Ativa", passagem.getCodigoAssento());
                    return;
                }
                aux = aux.getNext();
            }
        }
        
    } //OK

    private String mapaDeAssentos(String codVoo, ModuloVoos mv) { //Escolhendo o assento
        int re = 0, i, j;
        String assento;
        Assento[][] mapa = mv.consultarVoo(codVoo).getData().getMapa();
        System.out.println("\n[XX]d - Disponível | [XX]o - Ocupado.");
        for (i = 0; i < mapa.length; i++) {
            for (j = 0; j < mapa.length; j++) {
                if (j < 3) {
                    System.out.print("[" + mapa[i][j].getCodAssento() + (mapa[i][j].isDisponivel() ? "]d | " : "]o | "));
                } else if (j > 2) {
                    System.out.print("| [" + mapa[i][j].getCodAssento() + (mapa[i][j].isDisponivel() ? "]d " : "]o "));
                }
                if (j == 2) {
                    System.out.print("   ");
                }
            }
            System.out.println("");
        }
        do {
            System.out.print("Qual o assento você quer reservar?: ");
            assento = in.nextLine();
            if (assento.equals("SAIR")) {
                return "SAIR";
            }
            if (assento.length() == 2
                    && Character.isDigit(assento.charAt(0))
                    && Character.isAlphabetic(assento.charAt(1))) {
                for (i = 0; i < mapa.length; i++) {
                    for (j = 0; j < mapa.length; j++) {
                        if (mapa[i][j].getCodAssento().equals(assento)) {
                            if (mapa[i][j].isDisponivel()) {
                                System.out.println("Assento " + assento + " escolhido e reservado.");
                                mapa[i][j].setDisponivel(false);
                                mv.consultarVoo(codVoo).getData().setAssentosDisp(mv.consultarVoo(codVoo).getData().getAssentosDisp() - 1);
                                return assento;
                            } else {
                                System.out.println("Este assento já possui um cliente. Escolha outro.");
                            }
                        }
                    }
                }
            } else {
                System.out.println("Assento inválido.");
                re = 0;
            }
        } while (re == 0);
        return "SAIR";
    } //OK

    private String gerarCodigoReserva(String codVoo, String codAssento, String cpf) {
        Date data = new Date();
        SimpleDateFormat sdfD = new SimpleDateFormat("ddMMyyyy");
        String dataFormatada = sdfD.format(data); //transforma data em string
        String codReserva;
        
        codReserva = codVoo + codAssento + cpf + dataFormatada;
        return codReserva;
    } //OK

    public void consultarPassagensCliente(String cpf, ModuloClientes mc) { //Exibe todas as passagens ativas do cliente.
        int re = 0;
        NodeP aux = this.first;
        
        if (mc.buscarCliente(cpf) != null) {
            while (aux != null) {
                if (aux.getData().getCliente().getCpf().equals(cpf) && aux.getData().getStatus().equals("Ativa")) {
                    System.out.println(aux.getData());
                    re = 1;
                }
                aux = aux.getNext();
            }
            if (re == 0) {
                System.out.println("Este cliente não possui passagens ativas.");
            }
        }
        
    } //OK

    public void consultarHistoricoCliente(String cpf, ModuloClientes mc) { //Exibe todas as passagens do cliente.
        int re = 0;
        NodeP aux = first;
        if (mc.buscarCliente(cpf) != null) {
            while (aux != null) {
                if (aux.getData().getCliente().getCpf().equals(cpf)) {
                    System.out.println(aux.getData());
                    System.out.println("");
                    re = 1;
                }
                aux = aux.getNext();
            }
            if (re == 0) {
                System.out.println("Este cliente não possui passagens ativas.");
            }
        }
    } //OK

    public void cancelarPassagem(String codigoReserva, ListaTextoPassagem ltp) { //Faz o cancelamento de uma reserva do cliente
        /* OBSERVAÇÃO!!!
            - Após o cancelamento, é necessário mudar o status da reserva para cancelada,
        e libera o assento do vôo. OK
            - Deve-se gerar um documento de crédito com 50% do valor da passagem. OK
         */
        NodeP aux = first;
        Assento[][] mapa;
        if (first == null) {
            System.out.println("Lista de passagens vazia.");
        } else {
            while (aux != null) {
                if (codigoReserva.equalsIgnoreCase(aux.getData().getCodigoReserva())) {
                    if (aux.getData().getStatus().equals("Ativa")) {
                        mapa = aux.getData().getVoo().getMapa();
                        for (int i = 0; i < mapa.length; i++) {
                            for (int j = 0; j < mapa.length; j++) {
                                if (mapa[i][j].getCodAssento().equalsIgnoreCase(aux.getData().getCodigoAssento())) {
                                    aux.getData().setStatus("Cancelada");
                                    mapa[i][j].setDisponivel(true);
                                    aux.getData().getVoo().setAssentosDisp(aux.getData().getVoo().getAssentosDisp() + 1);
                                    ltp.alterarStatusPassagem(codigoReserva);
                                    System.out.println("Reserva cancelada.");
                                    System.out.println(aux.getData());
                                    System.out.println("Credito recebido de R$" + aux.getData().getVoo().getValorPassagem() * 0.5);
                                    return;
                                }
                            }
                        }
                    } else if (aux.getData().getStatus().equals("Cancelada")) {
                        System.out.println("Reserva já foi cancelada.");
                    } else {
                        System.out.println("Reserva já foi efetivada.");
                    }
                }
                aux = aux.getNext();
            }
            System.out.println("Reserva não existe.");
        }
    } //OK

    public int removerNode(Cliente cliente) { //Remover o histórico de passagens
        NodeP aux = first, aux2;
        int re = 0;
        
        if (first == null) {
            System.out.println("Lista Vazia.");
        } else if (qtd == 1) {
            if (first.getData().getCliente().equals(cliente)) {
                if (first.getData().getStatus().equals("Ativa")) {
                    System.out.println("Cliente possui passagens ativas. Não é possível removê-lo");
                    return 0;
                } else {
                    first = null;
                    last = null;
                    qtd = 0;
                }
            } else {
                System.out.println("Cliente não comprou nenhuma passagem.");
            }
        } else {
            while (aux != null) { //Percorrer para ver se não tem nenhuma passagem ativa
                if (aux.getData().getCliente().equals(cliente) && aux.getData().getStatus().equals("Ativa")) {
                    System.out.println("Cliente possui passagens ativas. Não é possível removê-lo");
                    return 0;
                }
            }
            if (first.getData().getCliente().equals(cliente)) {
                if (first.getData().getStatus().equals("Ativa")) {
                    System.out.println("Cliente possui passagens ativas. Não é possível removê-lo");
                    return 0;
                } else {
                    first = first.getNext();
                    first.setPrev(null);
                    qtd--;
                    re = 1;
                }
            }
            if (last.getData().getCliente().equals(cliente)) {
                if (first.getData().getStatus().equals("Ativa")) {
                    System.out.println("Cliente possui passagens ativas. Não é possível removê-lo");
                    return 0;
                } else {
                    last = last.getPrev();
                    last.setNext(null);
                    qtd--;
                    re = 1;
                }
            }
            while (aux != null) {
                if (aux.getData().getCliente().equals(cliente)) {
                    aux2 = aux.getPrev();
                    aux = aux.getNext();
                    aux2.setNext(aux);
                    aux.setPrev(aux2);
                    qtd--;
                    re = 1;
                }
                aux = aux.getNext();
            }
            if (re == 0) {
                System.out.println("Cliente não comprou nenhuma passagem.");
            }
        }
        return 1;
    } //OK

    public void consultarPassageiros(String codigoVoo, ModuloVoos mv) { //Exibe todos os clientes de um vôo.
        int re = 0;
        NodeP aux = first;
        
        if (mv.consultarVoo(codigoVoo) != null) {
            while (aux != null) {
                if (aux.getData().getVoo().getCodVoo().equals(codigoVoo) && (aux.getData().getStatus().equals("Ativa")
                        || aux.getData().getStatus().equals("Efetivada"))) {
                    System.out.println(aux.getData().getCliente() + " | Assento: " + aux.getData().getCodigoAssento());
                    System.out.println("");
                    re = 1; // Vôo existe e possui clientes
                }
                aux = aux.getNext();
            }
            if (re == 0) {
                System.out.println("Vôo não possui clientes.");
            }
        }
        
    } //OK

    public void reinserirListaPassagens(PassagemTexto p, ModuloClientes mc, ModuloVoos mv) {
        Date data = new Date();
        SimpleDateFormat sdfD = new SimpleDateFormat("dd/MM/yyyy");
        String dataFormatada = sdfD.format(data); //transforma data em string
        Date hora = Calendar.getInstance().getTime();
        SimpleDateFormat sdfH = new SimpleDateFormat("HH:mm");
        String horaFormatada = sdfH.format(hora); //transforma hora em string
        Passagem passagem = new Passagem(p.getCodigoReserva());
        passagem.setCliente(mc.buscarCliente(p.getCpf()).getData());
        passagem.setVoo(mv.consultarVoo(p.getCodVoo()).getData());
        
        passagem.setCodigoAssento(p.getCodigoAssento());
        if ((dataFormatada.compareTo(mv.consultarVoo(p.getCodVoo()).getData().getDataPartida()) > 0
                || (dataFormatada.compareTo(mv.consultarVoo(p.getCodVoo()).getData().getDataPartida()) == 0
                && horaFormatada.compareTo(mv.consultarVoo(p.getCodVoo()).getData().getHoraPartida()) >= 0))
                && p.getStatus().equals("Ativa")) {
            passagem.setStatus("Efetivada");
        } else {
            passagem.setStatus(p.getStatus());
        }
        
        NodeP novo = new NodeP(passagem);
        
        if (this.first == null) {
            this.first = novo;
            this.last = novo;
            this.qtd = 1;
        } else {
            this.last.setNext(novo);
            novo.setPrev(this.last);
            this.last = novo;
            this.qtd++;
        }
    } //OK
}
