package pacotePassagens;

public class NodeT {
    private NodeT next, prev;
    private PassagemTexto data;

    public NodeT(PassagemTexto data) {
        this.data = data;
    }

    public NodeT getNext() {
        return next;
    }

    public void setNext(NodeT next) {
        this.next = next;
    }

    public NodeT getPrev() {
        return prev;
    }

    public void setPrev(NodeT prev) {
        this.prev = prev;
    }

    public PassagemTexto getData() {
        return data;
    }

    public void setData(PassagemTexto data) {
        this.data = data;
    }
    
}
