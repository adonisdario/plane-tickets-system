package pacotePassagens;

import pacoteClientes.Cliente;
import java.io.Serializable;
import pacoteVoos.Voo;

public class Passagem implements Serializable {

    private final String codigoReserva;
    private String codigoAssento;
    private Voo voo;
    private Cliente cliente;
    private String status = "Ativa"; //0 = Ativa, 1 = efetivada ou 2 = cancelada.

    public Passagem(String codigoReserva) {
        this.codigoReserva = codigoReserva;
    }

    public String getCodigoReserva() {
        return codigoReserva;
    }

    public Voo getVoo() {
        return voo;
    }

    public void setVoo(Voo voo) {
        this.voo = voo;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public String getCodigoAssento() {
        return codigoAssento;
    }

    public void setCodigoAssento(String codigoAssento) {
        this.codigoAssento = codigoAssento;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "Passagem - " + "Código da Reserva: " + codigoReserva + ", Assento: " + codigoAssento
                + ", Status: " + status + "\nVoo( " + voo + ")\n Cliente(" + cliente + ")";
    }

}
