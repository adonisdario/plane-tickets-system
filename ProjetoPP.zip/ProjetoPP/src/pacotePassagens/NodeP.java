package pacotePassagens;

public class NodeP {

    private NodeP next, prev;
    private Passagem data;

    public NodeP(Passagem data) {
        this.data = data;
    }

    public NodeP getNext() {
        return next;
    }

    public void setNext(NodeP next) {
        this.next = next;
    }

    public NodeP getPrev() {
        return prev;
    }

    public void setPrev(NodeP prev) {
        this.prev = prev;
    }

    public Passagem getData() {
        return data;
    }

    public void setData(Passagem data) {
        this.data = data;
    }
}
