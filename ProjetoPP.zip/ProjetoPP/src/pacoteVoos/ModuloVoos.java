package pacoteVoos;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Scanner;
import projetopp.Validacao;

public class ModuloVoos {

    private NodeV first, last;
    private int qtd;
    Scanner in = new Scanner(System.in);

    /* OBSERVAÇÃO!!!
        - Antes do cadastramento, é necesário reconstruir a lista de vôos a partir
    do arquivo. OK
        - Mudar o status de todos os vôos cuja data é anterior à data atual. OK
     */
    public void efetivarVoos() {
        Date data = new Date();
        SimpleDateFormat sdfD = new SimpleDateFormat("dd/MM/yyyy");
        String dataFormatada = sdfD.format(data); //transforma data em string
        Date hora = Calendar.getInstance().getTime();
        SimpleDateFormat sdfH = new SimpleDateFormat("HH:mm");
        String horaFormatada = sdfH.format(hora); //transforma hora em string

        NodeV aux = first;

        if (first == null) {
            return;
        }
        while (aux != null) {
            if ((dataFormatada.compareTo(aux.getData().getDataPartida()) > 0
                    || (dataFormatada.compareTo(aux.getData().getDataPartida()) == 0
                    && horaFormatada.compareTo(aux.getData().getHoraPartida()) >= 0))
                    && aux.getData().getStatus() == true) {
                aux.getData().setStatus(false); //Efetivado
                Assento[][] mapa = aux.getData().getMapa();
                for (int i = 0; i < mapa.length; i++) {
                    for (int j = 0; j < mapa.length; j++) {
                        mapa[i][j].setDisponivel(true);
                    }
                }
                aux.getData().setAssentosDisp(36);
            }
            aux = aux.getNext();
        }
    } //OK

    public void cadastrarVoo(String codVoo, Validacao validacao) { //Cadastra os vôos na lista
        /* OBSERVAÇÃO!!!
            - Não podem existir dois vôos com o mesmo código. OK
            - O código do vôo deve conter 3 letras e 4 números nesta ordem. OK
            - A data da partida e chegada deve ser uma data válida, posterior a atual. OK
            - No final do programa, deve-se gravar os vôos no arquivo. OK
         */

        NodeV aux, novo;
        Voo voo;
        if (first == null) {
            System.out.println("Código do vôo: " + codVoo);
            voo = camposCadastro(codVoo, validacao);
            if (voo == null) {
                System.out.println("Saindo do cadastramento.");
                return;
            }
            novo = new NodeV(voo);
            first = novo;
            last = novo;
            qtd = 1;
            System.out.println("Vôo cadastrado.");
            return;
        } else if (codVoo.compareToIgnoreCase(first.getData().getCodVoo()) < 0) {
            voo = camposCadastro(codVoo, validacao);
            if (voo == null) {
                System.out.println("Saindo do cadastramento.");
                return;
            }
            novo = new NodeV(voo);
            novo.setNext(first);
            first.setPrev(novo);
            first = novo;
            qtd++;
            System.out.println("Código do vôo: " + codVoo);
            System.out.println("Vôo cadastrado.");
            return;
        } else if (codVoo.compareToIgnoreCase(last.getData().getCodVoo()) > 0) {
            voo = camposCadastro(codVoo, validacao);
            if (voo == null) {
                System.out.println("Saindo do cadastramento.");
                return;
            }
            novo = new NodeV(voo);
            last.setNext(novo);
            novo.setPrev(last);
            last = novo;
            qtd++;
            System.out.println("Vôo cadastrado.");
            return;
        } else {
            aux = first.getNext();
            while (aux != null) {
                if (codVoo.equalsIgnoreCase(aux.getData().getCodVoo())) {
                    System.out.println("Vôo já cadastrado.");
                    return;
                } else if (codVoo.compareToIgnoreCase(aux.getData().getCodVoo()) < 0) {
                    voo = camposCadastro(codVoo, validacao);
                    if (voo == null) {
                        System.out.println("Saindo do cadastramento.");
                        return;
                    }
                    novo = new NodeV(voo);
                    NodeV aux2 = aux.getPrev();
                    novo.setPrev(aux2);
                    novo.setNext(aux);
                    aux2.setNext(novo);
                    aux.setPrev(novo);
                    qtd++;
                    System.out.println("Vôo cadastrado.");
                    return;
                }
                aux = aux.getNext();
            }
        }
        System.out.println("Vôo já cadastrado.");

    } //OK

    private Voo camposCadastro(String codVoo, Validacao validacao) {
        Voo voo;
        String origem, destino, dataPartida, dataChegada, horaPartida, horaChegada;
        int re;
        double valorPassagem = 0;
        boolean v;

        voo = new Voo(codVoo);
        do {
            re = 1;
            System.out.print("Digite a Origem do Vôo (Capital/EF) (sem caracteres especiais): ");
            origem = in.nextLine();
            if (origem.equals("SAIR")) {
                System.out.println("Saindo do módulo.\n");
                return null;
            }
            if (origensDestinos(origem) == 0) {
                System.out.println("Origem não aceita.");
                re = 0;
            }
        } while (re == 0);
        do {
            re = 1;
            System.out.print("Digite a data de Partida do vôo (dd/MM/yyyy): ");
            dataPartida = in.nextLine();
            if (dataPartida.equals("SAIR")) {
                System.out.println("Saindo do módulo.\n");
                return null;
            }
            if (validacao.validarData(dataPartida) == 0) {
                System.out.println("Data inválida.");
                re = 0;
            }
        } while (re == 0);
        do {
            re = 1;
            System.out.print("Digite a hora da Partida do vôo (hh:mm): ");
            horaPartida = in.nextLine();
            if (horaPartida.equals("SAIR")) {
                System.out.println("Saindo do módulo.\n");
                return null;
            }
            if (validacao.validarHora(horaPartida, dataPartida) == 0) {
                System.out.println("Hora inválida.");
                re = 0;
            }
        } while (re == 0);
        do {
            re = 1;
            System.out.print("Digite o Destino do Vôo (Capital/EF)(sem caracteres especiais): ");
            destino = in.nextLine();
            if (destino.equals("SAIR")) {
                System.out.println("Saindo do módulo.\n");
                return null;
            }
            if (origensDestinos(destino) == 0) {
                System.out.println("Destino não aceito.");
                re = 0;
            }
            if (destino.equals(origem)) {
                System.out.println("Destino igual a origem");
                re = 0;
            }
        } while (re == 0);
        do {
            re = 1;
            System.out.print("Digite a data de Chegada do vôo (dd/MM/yyyy): ");
            dataChegada = in.nextLine();
            if (dataChegada.equals("SAIR")) {
                System.out.println("Saindo do módulo.\n");
                return null;
            }
            if (validacao.validarData(dataChegada) == 0 || dataChegada.compareTo(dataPartida) < 0) {
                System.out.println("Data inválida.");
                re = 0;
            }
        } while (re == 0);
        do {
            re = 1;
            System.out.print("Digite a hora de Chegada do vôo (hh:mm): ");
            horaChegada = in.nextLine();
            if (horaChegada.equals("SAIR")) {
                System.out.println("Saindo do módulo.\n");
                return null;
            }
            if (validacao.validarHora(horaChegada, dataChegada) == 0 || (dataPartida.equals(dataChegada)
                    && horaChegada.compareTo(horaPartida) < 0)) {
                System.out.println("Hora inválida.");
                re = 0;
            }
        } while (re == 0);
        do {
            v = false;
            System.out.print("Digite o preço da passagem: ");
            try {
                valorPassagem = in.nextDouble();
                in.nextLine();
                v = true;
                if (valorPassagem < 1) {
                    System.out.println("Preço não aceito");
                }
            } catch (java.util.InputMismatchException ex) {
                System.err.println("Digite apenas Números\n");
                in.nextLine();
            }
        } while (v == false || valorPassagem < 1);
        construirMapa(voo);
        voo.setOrigem(origem);
        voo.setDataPartida(dataPartida);
        voo.setHoraPartida(horaPartida);
        voo.setDestino(destino);
        voo.setDataChegada(dataChegada);
        voo.setHoraChegada(horaChegada);
        voo.setValorPassagem(valorPassagem);
        voo.setStatus(true);//Ativo = True, Efetivado = False.
        return voo;
    } //OK

    public void construirMapa(Voo voo) { //Construir o mapa
        Assento[][] mapa = voo.getMapa();
        String let = "a", num = "0";
        for (int i = 0; i < mapa.length; i++) {
            switch (i) {
                case 0:
                    num = "0";
                    break;
                case 1:
                    num = "1";
                    break;
                case 2:
                    num = "2";
                    break;
                case 3:
                    num = "3";
                    break;
                case 4:
                    num = "4";
                    break;
                case 5:
                    num = "5";
                    break;
            }
            for (int j = 0; j < mapa.length; j++) {
                switch (j) {
                    case 0:
                        let = "A";
                        break;
                    case 1:
                        let = "B";
                        break;
                    case 2:
                        let = "C";
                        break;
                    case 3:
                        let = "D";
                        break;
                    case 4:
                        let = "E";
                        break;
                    case 5:
                        let = "F";
                        break;
                }
                mapa[i][j] = new Assento();
                mapa[i][j].setCodAssento(num + let);
            }
        }
        voo.setMapa(mapa);
    } //OK

    public int origensDestinos(String cidade) {
        String[] capitais = new String[27];
        for (int i = 0; i < capitais.length; i++) {
            capitais[0] = "Aracaju/SE";
            capitais[1] = "Belem/PA";
            capitais[2] = "Belo Horizonte/MG";
            capitais[3] = "Boa Vista/RR";
            capitais[4] = "Brasília/DF";
            capitais[5] = "Campo Grande/MS";
            capitais[6] = "Cuiaba/MT";
            capitais[7] = "Curitiba/PR";
            capitais[8] = "Florianopolis/SC";
            capitais[9] = "Fortaleza/CE";
            capitais[10] = "Goiania/GO";
            capitais[11] = "João Pessoa/PB";
            capitais[12] = "Macapa/AP";
            capitais[13] = "Maceio/AL";
            capitais[14] = "Manaus/AM";
            capitais[15] = "Natal/RN";
            capitais[16] = "Palmas/TO";
            capitais[17] = "Porto Alegre/RS";
            capitais[18] = "Porto Velho/RO";
            capitais[19] = "Recife/PE";
            capitais[20] = "Rio Branco/AC";
            capitais[21] = "Rio de Janeiro/RJ";
            capitais[22] = "Salvador/BA";
            capitais[23] = "Sao Luis/MA";
            capitais[24] = "Sao Paulo/SP";
            capitais[25] = "Teresina/PI";
            capitais[26] = "Vitoria/ES";
            if (cidade.equalsIgnoreCase(capitais[i])) {
                return 1;
            }
        }
        return 0;
    } //OK

    public void buscarVoo(String origem, String destino, String dataPartida, String dataChegada) { //Exibe o código do voo, horário, poltronas disponíveis
        /* OBSERVAÇÃO!!!
            - Exibir somente vôos com poltronas disponíveis e que estão ativos OK
         */
        NodeV aux = first;
        int re = 0;
        System.out.println("\nVôos encontrados: \n");
        while (aux != null) {
            if (aux.getData().getOrigem().equalsIgnoreCase(origem)
                    && (aux.getData().getDestino().equalsIgnoreCase(destino))
                    && (aux.getData().getDataPartida().equalsIgnoreCase(dataPartida))
                    && (aux.getData().getDataChegada().equalsIgnoreCase(dataChegada))
                    && (aux.getData().getStatus())
                    && (aux.getData().getAssentosDisp() > 0)) {
                re = 1;
                System.out.println("Código Vôo: " + aux.getData().getCodVoo());
                System.out.println("Horário de Partida: " + aux.getData().getHoraPartida());
                System.out.println("Horário de Chegada: " + aux.getData().getHoraChegada());
                System.out.println("Quantidade de Assentos disponíveis: \n" + aux.getData().getAssentosDisp());
            }
            aux = aux.getNext();
        }
        if (re == 0) {
            System.out.println("Nenhum vôo com os filtros colocados disponível.");
        }
    } //OK

    public void alterarValorPassagem(String codVoo) { //Altera o valor da passagem de um vôo
        /* OBSERVAÇÃO!!!
            - Só é permitido alterar o valor da passagem de vôos estejam ativos. OK
         */
        NodeV aux = first;
        double valor = 0;
        boolean v;
        while (aux != null) {
            if (aux.getData().getCodVoo().equals(codVoo)) {
                if (aux.getData().getStatus() == true) { // Ativo

                    do {
                        v = false;
                        try {
                            System.out.print("Digite o novo valor da passagem: ");
                            valor = in.nextDouble();
                            v = true;
                        } catch (java.util.InputMismatchException ex) {
                            System.err.println("Digite apenas Números\n");
                            in.nextLine();
                        }
                    } while (v == false || valor <= 0);

                    aux.getData().setValorPassagem(valor);
                    System.out.println("Valor da passagem alterado.");
                    return;
                } else {
                    System.out.println("Vôo já efetivado, não há como mudar o valor da passagem.");
                    return;
                }
            }
            aux = aux.getNext();
        }
        System.out.println("Vôo não existe.");
    } //OK

    public void cancelarVoo(String codVoo) { //Remove um vôo
        /* OBSERVAÇÃO!!!
            - Só é permitido remover um vôo que esteja ativo e que todos os assentos estejam disponíveis. OK
         */
        NodeV aux = first, aux2;

        if (first == null) {
            System.out.println("Lista Vazia");
        } else if (consultarVoo(codVoo) == null) {

        } else if (qtd == 1) {
            if (first.getData().getCodVoo().equals(codVoo)) {
                if (first.getData().getStatus()) {
                    if (first.getData().getAssentosDisp() == 36) {
                        first = null;
                        last = null;
                        qtd = 0;
                    } else {
                        System.out.println("Algum cliente já comprou uma passagem para este vôo. Não é possível removê-lo.");
                    }
                } else {
                    System.out.println("Vôo efetivado. Não é possível removê-lo.");
                }
            }
        } else if (first.getData().getCodVoo().equals(codVoo)) {
            if (first.getData().getStatus()) {
                if (first.getData().getAssentosDisp() == 36) {
                    first = first.getNext();
                    first.setPrev(null);
                    qtd--;
                } else {
                    System.out.println("Algum cliente já comprou uma passagem para este vôo. Não é possível removê-lo.");
                }
            } else {
                System.out.println("Vôo efetivado. Não é possível removê-lo.");
            }
        } else if (last.getData().getCodVoo().equals(codVoo)) {
            if (first.getData().getStatus()) {
                if (first.getData().getAssentosDisp() == 36) {
                    last = last.getPrev();
                    last.setNext(null);
                    qtd--;
                } else {
                    System.out.println("Algum cliente já comprou uma passagem para este vôo. Não é possível removê-lo.");
                }
            } else {
                System.out.println("Vôo efetivado. Não é possível removê-lo.");
            }
        } else {
            while (aux != null) {
                if (aux.getData().getCodVoo().equals(codVoo)) {
                    if (first.getData().getStatus()) {
                        if (first.getData().getAssentosDisp() == 36) {
                            aux2 = aux.getPrev();
                            aux = aux.getNext();
                            aux2.setNext(aux);
                            aux.setPrev(aux2);
                            qtd--;
                            return;
                        } else {
                            System.out.println("Algum cliente já comprou uma passagem para este vôo. Não é possível removê-lo.");
                        }
                    } else {
                        System.out.println("Vôo efetivado. Não é possível removê-lo.");
                    }
                }
            }
        }
    } //OK

    public NodeV consultarVoo(String codVoo) { //Retorna a referência para o nó
        NodeV aux = first;
        while (aux != null) {
            if (aux.getData().getCodVoo().equals(codVoo)) {
                return aux;
            }
            aux = aux.getNext();
        }
        System.out.println("Vôo não existe.");
        return null;
    } //OK

    public void reinserirListaVoos(Voo v) {
        NodeV novo = new NodeV(v);

        if (this.first == null) {
            this.first = novo;
            this.last = novo;
            this.qtd = 1;
        } else {
            this.last.setNext(novo);
            novo.setPrev(this.last);
            this.last = novo;
            this.qtd++;
        }
    } //OK

    public void gravarListaVoos(String nomeArq) { // Da lista para o arquivo
        NodeV aux = this.first;

        if (this.first == null) {
            ArquivoObjetoVoo arq = new ArquivoObjetoVoo();
            arq.openToWrite(nomeArq);
            arq.gravarVoo(null);
            arq.closeWriteFile();
        } else {
            ArquivoObjetoVoo arq = new ArquivoObjetoVoo();
            arq.openToWrite(nomeArq);
            while (aux != null) {
                arq.gravarVoo(aux.getData());
                aux = aux.getNext();
            }
            arq.closeWriteFile();
        }
    } //OK

    public void carregarListaVoos(String nomeArq) { // Do arquivo para a lista
        ArquivoObjetoVoo arq = new ArquivoObjetoVoo();
        Voo v;

        boolean exists = arq.openToRead(nomeArq);
        if (exists == true) {
            v = arq.lerVoo();
            while (v != null) {
                this.reinserirListaVoos(v);
                v = arq.lerVoo();
            }
            arq.closeReadFile();
            System.out.println("Arquivo Vôos aberto.");
        } else {
            arq.openToWrite("Voos");
            arq.closeWriteFile();
            System.out.println("Arquivo Vôos criado.");
        }
    } //OK
}
