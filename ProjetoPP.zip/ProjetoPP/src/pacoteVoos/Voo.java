package pacoteVoos;

import java.io.Serializable;

public class Voo implements Serializable {

    private final String codVoo;
    private int assentosDisp = 36;
    private String origem, destino, dataPartida, horaPartida, dataChegada, horaChegada;
    private Assento mapa[][] = new Assento[6][6];
    private double valorPassagem;
    private boolean status; //Ativo ou Efetivado.

    public Voo(String codVoo) {
        this.codVoo = codVoo;
    }

    public String getCodVoo() {
        return codVoo;
    }

    public String getOrigem() {
        return origem;
    }

    public void setOrigem(String origem) {
        this.origem = origem;
    }

    public String getDestino() {
        return destino;
    }

    public void setDestino(String destino) {
        this.destino = destino;
    }

    public String getDataPartida() {
        return dataPartida;
    }

    public void setDataPartida(String dataPartida) {
        this.dataPartida = dataPartida;
    }

    public String getHoraPartida() {
        return horaPartida;
    }

    public void setHoraPartida(String horaPartida) {
        this.horaPartida = horaPartida;
    }

    public String getDataChegada() {
        return dataChegada;
    }

    public void setDataChegada(String dataChegada) {
        this.dataChegada = dataChegada;
    }

    public String getHoraChegada() {
        return horaChegada;
    }

    public void setHoraChegada(String horaChegada) {
        this.horaChegada = horaChegada;
    }

    public Assento[][] getMapa() {
        return mapa;
    }

    public void setMapa(Assento[][] mapa) {
        this.mapa = mapa;
    }
    

    public double getValorPassagem() {
        return valorPassagem;
    }

    public void setValorPassagem(double valorPassagem) {
        this.valorPassagem = valorPassagem;
    }

    public boolean getStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public int getAssentosDisp() {
        return assentosDisp;
    }

    public void setAssentosDisp(int assentosDisp) {
        this.assentosDisp = assentosDisp;
    }

    @Override
    public String toString() {
        return "Vôo " + codVoo + " | Assentos Disponíveis: " + assentosDisp
                + " | Origem: " + origem + " | Destino: " + destino + "\n            | Data de Partida: " + dataPartida
                + " | Hora de Partida: " + horaPartida + " | Data de Chegada: " + dataChegada + " | Hora de Chegada: "
                + horaChegada + " | Valor da Passagem: R$" + valorPassagem + " | Status: " + (status ? "Ativo" : "Efetivado");
    }

}
