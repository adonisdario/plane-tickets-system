package pacoteVoos;

import java.io.Serializable;

public class Assento implements Serializable {

    private boolean disponivel = true;
    private String codAssento;

    public boolean isDisponivel() {
        return disponivel;
    }

    public void setDisponivel(boolean disponivel) {
        this.disponivel = disponivel;
    }

    public String getCodAssento() {
        return codAssento;
    }

    public void setCodAssento(String codAssento) {
        this.codAssento = codAssento;
    }

}
