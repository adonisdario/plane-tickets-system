package pacoteVoos;

public class NodeV {
    private NodeV next, prev;
    private Voo data;

    public NodeV(Voo data) {
        this.data = data;
    }
    
    public NodeV getNext() {
        return next;
    }

    public void setNext(NodeV next) {
        this.next = next;
    }

    public NodeV getPrev() {
        return prev;
    }

    public void setPrev(NodeV prev) {
        this.prev = prev;
    }

    public Voo getData() {
        return data;
    }

    public void setData(Voo data) {
        this.data = data;
    }

}
