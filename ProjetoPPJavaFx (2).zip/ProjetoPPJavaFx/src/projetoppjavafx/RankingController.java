/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetoppjavafx;

import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextArea;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.VBox;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.paint.Paint;
import javafx.scene.shape.StrokeLineCap;
import javafx.scene.shape.StrokeLineJoin;
import javafx.scene.shape.StrokeType;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import pacoteJogo.ListaRanking;
import pacoteJogo.NodeRanking;
import pacoteJogo.Ranking;

/**
 * FXML Controller class
 *
 * @author DELL
 */
public class RankingController implements Initializable {

    @FXML
    private Text titulo1;

    @FXML
    private Text titulo2;

    @FXML
    private Button botaoParaSair;

    @FXML
    private VBox vbox;
    private ListaRanking lr;
    
    private Media botoes = new Media("file:///C:/Users/DELL/Documents/NetBeansProjects/ProjetoPPJavaFx/src/Sons/interface_click.wav");
    private MediaPlayer mediaPlayer = new MediaPlayer(botoes);

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        Text l;
        lr = new ListaRanking();
        lr.carregarListaRanking("Highscores");
        lr.exibirMultiplayer();
        NodeRanking aux = lr.first;
        int cont = 1;
        while (aux != null) {
            l = new Text();
            l.setFont(Font.font("Rockwell", 25));
            l.setStroke(Paint.valueOf("#ffffff"));
            l.setFill(Paint.valueOf("#ff1111"));
            l.setStrokeType(StrokeType.OUTSIDE);
            l.setStrokeLineCap(StrokeLineCap.SQUARE);
            l.setStrokeWidth(2);
            l.setStrokeLineJoin(StrokeLineJoin.ROUND);
            l.setText(cont +"º - "+ aux.getData().toString());
            vbox.getChildren().addAll(l);
            aux = aux.getNext();
            cont++;
        }
    }

    @FXML
    public void sairRanking(MouseEvent event) {
        mediaPlayer.setVolume(0.2);
        mediaPlayer.setAutoPlay(true);
        lr.gravarListaRanking("Highscores");
        System.out.println("Voltando ao menu pricipal.");
        MainRanking.stage.close();
        ProjetoPPJavaFx menu = new ProjetoPPJavaFx();
        try {
            menu.start(new Stage());
        } catch (Exception ex) {
            Logger.getLogger(FXMLMenuController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}
