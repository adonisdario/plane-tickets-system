/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetoppjavafx;

import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.input.MouseEvent;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.text.Text;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author DELL
 */
public class RegrasController implements Initializable {

    @FXML
    private Text titulo1;

    @FXML
    private Text titulo2;

    @FXML
    private Button botaoSair;
    
    private Media botoes = new Media("file:///C:/Users/DELL/Documents/NetBeansProjects/ProjetoPPJavaFx/src/Sons/interface_click.wav");
    private MediaPlayer mediaPlayer = new MediaPlayer(botoes);

    @FXML
    void sairTela(MouseEvent event) {
        mediaPlayer.setVolume(0.2);
        mediaPlayer.setAutoPlay(true);
        System.out.println("Voltando ao menu pricipal.");
        MainRegras.stage.close();
        ProjetoPPJavaFx menu = new ProjetoPPJavaFx();
        try {
            menu.start(new Stage());
        } catch (Exception ex) {
            Logger.getLogger(FXMLMenuController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

}
