package projetoppjavafx;

import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.animation.Animation;
import javafx.animation.AnimationTimer;
import javafx.animation.SequentialTransition;
import javafx.animation.TranslateTransition;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.util.Duration;
import pacoteJogo.ListaRanking;
import pacoteJogo.Maos;
import static projetoppjavafx.JogarMPController.maos1;
import static projetoppjavafx.JogarMPController.maos2;
import static projetoppjavafx.JogarMPController.fila;
import static projetoppjavafx.JogarMPController.primeiro;

/**
 * FXML Controller class
 *
 * @author DELL
 */
public class MPController implements Initializable {

    public Maos prim;

    @FXML
    private Text vezDe;

    @FXML
    private Text jogador1;

    @FXML
    private Text jogador2;

    @FXML
    private Label ptsj1;

    @FXML
    private Label ptsj2;

    @FXML
    private Label jogadorDaVez;

    @FXML
    private ImageView maoDir1;

    @FXML
    private ImageView maoEsq1;

    @FXML
    private ImageView maoDir2;

    @FXML
    private ImageView maoEsq2;

    @FXML
    private Button j1dividirpontos;

    @FXML
    private Button j2dividirpontos;

    @FXML
    private Label j1naopodedividir;

    @FXML
    private Label j2naopodedividir;

    @FXML
    private Label naopodeusar1;

    @FXML
    private Label naopodeusar2;

    @FXML
    private Text nomeVencedor;

    @FXML
    private Text vencedor;

    @FXML
    private Button sair;

    @FXML
    private Button jogarNovamente;

    @FXML
    private Text selecionouMaoEsq1;

    @FXML
    private Text selecionouMaoDir1;

    @FXML
    private Text selecionouMaoDir2;

    @FXML
    private Text selecionouMaoEsq2;

    @FXML
    private Text rod;

    @FXML
    private Label contaRodada;

    @FXML
    private Label igual1;

    @FXML
    private Label j2;

    @FXML
    private Label mais1;

    @FXML
    private Label j1;

    @FXML
    private Label resultado;

    @FXML
    private Label cinco2;

    @FXML
    private Label menos;

    @FXML
    private Label resultado3;

    @FXML
    private Label resultado4;

    @FXML
    private Label cinco;

    @FXML
    private Label maiorQue;

    @FXML
    private Label resultado2;

    @FXML
    private Label igual2;

    private TranslateTransition transicao, voltar;
    private SequentialTransition sq;
    private int mao, rodada = 1;
    private AnimationTimer at, an;
    private URL url2;
    private ResourceBundle rb2;
    private ListaRanking listaR;
    private int partidas = 0;
    private Media botaodividir, botoes, vitoria, perdeuMao;
    private MediaPlayer mpb, mediaPlayer, mpv, mpm;
    private int cont = 0;
    private boolean flag = false;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        listaR = new ListaRanking();
        listaR.carregarListaRanking("Highscores");
        listaR.exibirMultiplayer();
        url2 = url;
        rb2 = rb;
        jogador1.setText(maos1.getNomeJogador()); //NOME DOS JOGADORES FIXO NA TELA
        jogador2.setText(maos2.getNomeJogador());
        jogarNovamente.setDisable(true); //BOTÃO PARA JOGAR NOVAMENTE
        jogarNovamente.setVisible(false);
        vencedor.setVisible(false); //PRINTS EXIBINDO VENCEDOR
        nomeVencedor.setVisible(false);
        selecionouMaoEsq1.setVisible(false); //PRINTS EXIBINDO MÃO ESCOLHIDA
        selecionouMaoDir1.setVisible(false);
        selecionouMaoEsq2.setVisible(false);
        selecionouMaoDir2.setVisible(false);
        j1.setVisible(false); //PRINTS EXIBINDO A SOMA QUE FOI FEITA
        mais1.setVisible(false);
        j2.setVisible(false);
        igual1.setVisible(false);
        resultado.setVisible(false);
        resultado2.setVisible(false);
        maiorQue.setVisible(false);
        cinco.setVisible(false);
        resultado3.setVisible(false);
        menos.setVisible(false);
        cinco2.setVisible(false);
        igual2.setVisible(false);
        resultado4.setVisible(false);

        if (fila.head().getData().equals(maos1)) {
            maoEsq2.setDisable(true); //DESABILITANDO AS MÃOS DO JOGADOR 2
            maoDir2.setDisable(true);
            naopodeusar2.setText("Não pode selecionar estas mãos!");
            naopodeusar1.setText("");
        } else {
            maoEsq1.setDisable(true); //DESABILITANDO AS MÃOS DO JOGADOR 1
            maoDir1.setDisable(true);
            naopodeusar1.setText("Não pode selecionar estas mãos!");
            naopodeusar2.setText("");
        }
        System.out.println("\nRODADA " + rodada);
        System.out.println("\n" + maos2.getNomeJogador() + " | Pontuação: " + maos2.getPontos());
        System.out.println("DIR: " + maos2.getDir() + " | ESQ: " + maos2.getEsq());
        System.out.println("\nESQ: " + maos1.getEsq() + " | DIR: " + maos1.getDir());
        System.out.println(maos1.getNomeJogador() + " | Pontuação: " + maos1.getPontos());

        at = new AnimationTimer() {
            @Override
            public void handle(long now) {
                if (flag) {
                    cont++;
                }
                jogadorDaVez.setText(fila.head().getData().getNomeJogador()); //MOSTA O JOGADOR QUE ESTÁ NA VEZ
                ptsj1.setText("" + maos1.getPontos());
                ptsj2.setText("" + maos2.getPontos());
                contaRodada.setText("" + rodada);
                try {
                    if (fila.head().getData().equals(maos1)) { //Jogador 1 está na vez
                        j2dividirpontos.setDisable(true); //DESABLITANDO O BOTÃO DE DIVIDIR DO JOGADOR 2
                        if ((maos1.getEsq() + maos1.getDir()) % 2 == 0
                                && (maos1.getEsq() != maos1.getDir())) { //Jogador 1 pode dividir pontos
                            j1naopodedividir.setText("");
                            j1dividirpontos.setDisable(false); //HABILITA O BOTÃO PARA DIVIDIR PONTOS
                        } else { //Jogador 1 não pode dividir pontos
                            j1naopodedividir.setText("Não pode dividir pontos!");
                            j1dividirpontos.setDisable(true); //DESABILITA O BOTÃO PARA DIVIDIR PONTOS
                        }
                        if (maos1.getEsq() == 5) { //Mao Esq1 possui 5 pontos
                            maoEsq1.setVisible(false); //DESABILITANDO A MÃO QUE FOI PERDIDA
                            maoEsq1.setDisable(true);
                            maos1.setEsq(0); // SETANDO MAO ESQ1 = 0
                            perdeuMao = new Media("file:///C:/Users/DELL/Documents/NetBeansProjects/ProjetoPPJavaFx/src/Sons/farmdie.wav");
                            mpm = new MediaPlayer(perdeuMao);
                            mpm.setVolume(0.2);
                            mpm.setAutoPlay(true);
                            System.out.println(maos1.getNomeJogador() + " perdeu a mão esquerda!");
                        }
                        if (maos1.getDir() == 5) { //Mao Dir1 possui 5 pontos
                            maoDir1.setVisible(false); //DESABILITANDO A MÃO QUE FOI PERDIDA
                            maoDir1.setDisable(true);
                            maos1.setDir(0); // SETANDO MAO DIR1 = 0
                            perdeuMao = new Media("file:///C:/Users/DELL/Documents/NetBeansProjects/ProjetoPPJavaFx/src/Sons/farmdie.wav");
                            mpm = new MediaPlayer(perdeuMao);
                            mpm.setVolume(0.2);
                            mpm.setAutoPlay(true);
                            System.out.println(maos1.getNomeJogador() + " perdeu a mão direita!");
                        }
                        if (maos1.getEsq() + maos1.getDir() == 0) { // Jogador 1 não possui mais mãos
                            at.stop();
                            maoDir1.setVisible(false); //DESABILITA AS MÃOS DO JOGADOR 1
                            maoDir1.setDisable(true);
                            maoEsq1.setVisible(false);
                            maoEsq1.setDisable(true);
                            ptsj1.setText("" + maos1.getPontos());
                            ptsj2.setText("" + maos2.getPontos());
                            System.out.println("\nRODADA " + rodada);
                            System.out.println("\n" + maos2.getNomeJogador() + " | Pontuação: " + maos2.getPontos());
                            System.out.println("DIR: " + maos2.getDir() + " | ESQ: " + maos2.getEsq());
                            System.out.println("\nESQ: " + maos1.getEsq() + " | DIR: " + maos1.getDir());
                            System.out.println(maos1.getNomeJogador() + " | Pontuação: " + maos1.getPontos());
                            System.out.println(maos1.getNomeJogador() + " não tem mais mãos em jogo!");
                            System.out.println(maos2.getNomeJogador() + " é o VENCEDOR!");
                            maos2.setPontos(maos2.getPontos() + rodada);
                            ptsj2.setText("" + maos2.getPontos());
                            maos2.setVitorias(maos2.getVitorias() + 1);
                            maos1.setDerrotas(maos1.getDerrotas() + 1);
                            vitoria = new Media("file:///C:/Users/DELL/Documents/NetBeansProjects/ProjetoPPJavaFx/src/Sons/win.wav");
                            mpv = new MediaPlayer(vitoria);
                            mpv.setVolume(0.2);
                            mpv.setAutoPlay(true);
                            vezDe.setVisible(false);
                            jogadorDaVez.setVisible(false);
                            jogarNovamente.setDisable(false);
                            jogarNovamente.setVisible(true);
                            vencedor.setVisible(true);
                            nomeVencedor.setText(maos2.getNomeJogador());
                            nomeVencedor.setVisible(true);
                            System.out.println("VENCEDOR: " + maos2.getNomeJogador() + " | PONTOS: " + maos2.getPontos());
                            System.out.println("perdedor: " + maos1.getNomeJogador() + " | pontos: " + maos1.getPontos());
                            rodada = 1;
                            partidas++;
                        }
                        if (mao == 12) { // Jogador 1 fez Esq1 com Dir2
                            j1.setText("" + maos1.getEsq()); //PRINTS DE SOMA
                            j2.setText("" + maos2.getDir());
                            resultado.setText("" + (maos1.getEsq() + maos2.getDir()));
                            j1.setVisible(true); //HABILITANDO PRINTS EXIBINDO A SOMA QUE FOI FEITA
                            mais1.setVisible(true);
                            j2.setVisible(true);
                            igual1.setVisible(true);
                            resultado.setVisible(true);
                            selecionouMaoEsq1.setVisible(false); // DESABILITANDO O PRINT DA MÃO ESCOLHIDA
                            flag = true;
                            if (cont == 130) { //TEMPO DE ESPERA PARA CONCLUIR A ANIMAÇÃO
                                System.out.println(maos1.getNomeJogador() + " somou sua Mão Esquerda com Mão Direita de " + maos2.getNomeJogador());
                                if (maos1.getEsq() + maos2.getDir() > 5) {
                                    resultado2.setText(resultado.getText()); //PRINTS DE SOMA MAIOR QUE 5
                                    resultado3.setText(resultado.getText());
                                    System.out.println(maos1.getEsq() + " + " + maos2.getDir() + " = " + (maos1.getEsq() + maos2.getDir())
                                            + " - 5 = " + (maos1.getEsq() + maos2.getDir() - 5));
                                    maos2.setDir(maos1.getEsq() + maos2.getDir() - 5);
                                    resultado4.setText("" + maos2.getDir()); //PRINTS DE SOMA MAIOR QUE 5
                                    resultado2.setVisible(true); //HABILITANDO PRINTS DE SOMA MAIOR QUE 5
                                    maiorQue.setVisible(true);
                                    cinco.setVisible(true);
                                    resultado3.setVisible(true);
                                    menos.setText("-");
                                    menos.setVisible(true);
                                    cinco2.setText("5");
                                    cinco2.setVisible(true);
                                    igual2.setVisible(true);
                                    resultado4.setVisible(true);
                                } else {
                                    maos2.setDir(maos1.getEsq() + maos2.getDir());
                                }
                                cont = 0; // resetando o contador de tempo
                                flag = false; //resetando a flag para o contador
                                mao = 0; //resetando a flag da ação do jogador
                                rodada++; // contador de rodadas incrementado
                                maoDir2.setImage(maos2.getMaoDir()); //mão que sofreu a soma com imagem atualizada
                                fila.enqueue(fila.dequeue()); //troca o turno
                                naopodeusar1.setText("Não pode selecionar estas mãos!");
                                naopodeusar2.setText("");
                                maos1.setPontos(maos1.getPontos() + maos2.getDir() + maos2.getEsq()); //AUMENTANDO A PONTUAÇÃO DO JOGADOR 1
                                System.out.println("\nRODADA " + rodada);
                                System.out.println("\n" + maos2.getNomeJogador() + " | Pontuação: " + maos2.getPontos());
                                System.out.println("DIR: " + maos2.getDir() + " | ESQ: " + maos2.getEsq());
                                System.out.println("\nESQ: " + maos1.getEsq() + " | DIR: " + maos1.getDir());
                                System.out.println(maos1.getNomeJogador() + " | Pontuação: " + maos1.getPontos());
                            }
                        } else if (mao == 22) { //Jogador 1 fez Dir1 com Dir2
                            j1.setText("" + maos1.getDir()); //PRINTS DE SOMA
                            j2.setText("" + maos2.getDir());
                            resultado.setText("" + (maos1.getDir() + maos2.getDir()));
                            j1.setVisible(true); //HABILITANDO PRINTS EXIBINDO A SOMA QUE FOI FEITA
                            mais1.setVisible(true);
                            j2.setVisible(true);
                            igual1.setVisible(true);
                            resultado.setVisible(true);
                            selecionouMaoDir1.setVisible(false); //DESABILITANDO PRINT DA MÃO ESCOLHIDA
                            flag = true;
                            if (cont == 130) {
                                System.out.println(maos1.getNomeJogador() + " somou sua Mão Direita com Mão Direita de " + maos2.getNomeJogador());
                                if (maos1.getDir() + maos2.getDir() > 5) {
                                    resultado2.setText(resultado.getText()); //PRINTS DE SOMA MAIOR QUE 5
                                    resultado3.setText(resultado.getText());
                                    System.out.println(maos1.getDir() + " + " + maos2.getDir() + " = " + (maos1.getDir() + maos2.getDir())
                                            + " - 5 = " + (maos1.getDir() + maos2.getDir() - 5));
                                    maos2.setDir(maos1.getDir() + maos2.getDir() - 5);
                                    resultado4.setText("" + maos2.getDir()); //PRINTS DE SOMA MAIOR QUE 5
                                    resultado2.setVisible(true); //HABILITANDO PRINTS DE SOMA MAIOR QUE 5
                                    maiorQue.setVisible(true);
                                    cinco.setVisible(true);
                                    resultado3.setVisible(true);
                                    menos.setText("-");
                                    menos.setVisible(true);
                                    cinco2.setText("5");
                                    cinco2.setVisible(true);
                                    igual2.setVisible(true);
                                    resultado4.setVisible(true);
                                } else {
                                    maos2.setDir(maos1.getDir() + maos2.getDir());
                                }
                                cont = 0;
                                flag = false;
                                mao = 0;
                                rodada++;
                                maoDir2.setImage(maos2.getMaoDir());
                                fila.enqueue(fila.dequeue());
                                naopodeusar1.setText("Não pode selecionar estas mãos!");
                                naopodeusar2.setText("");
                                maos1.setPontos(maos1.getPontos() + maos2.getDir() + maos2.getEsq()); //AUMENTANDO A PONTUAÇÃO DO JOGADOR 1
                                System.out.println("\nRODADA " + rodada);
                                System.out.println("\n" + maos2.getNomeJogador() + " | Pontuação: " + maos2.getPontos());
                                System.out.println("DIR: " + maos2.getDir() + " | ESQ: " + maos2.getEsq());
                                System.out.println("\nESQ: " + maos1.getEsq() + " | DIR: " + maos1.getDir());
                                System.out.println(maos1.getNomeJogador() + " | Pontuação: " + maos1.getPontos());
                            }
                        } else if (mao == 21) { // Jogador 1 fez Dir1 com Esq2
                            j1.setText("" + maos1.getDir()); //PRINTS DE SOMA
                            j2.setText("" + maos2.getEsq());
                            resultado.setText("" + (maos1.getDir() + maos2.getEsq()));
                            j1.setVisible(true); //HABILITANDO PRINTS EXIBINDO A SOMA QUE FOI FEITA
                            mais1.setVisible(true);
                            j2.setVisible(true);
                            igual1.setVisible(true);
                            resultado.setVisible(true);
                            selecionouMaoDir1.setVisible(false);
                            flag = true;
                            if (cont == 130) {
                                System.out.println(maos1.getNomeJogador() + " somou sua Mão Direita com Mão Esquerda de " + maos2.getNomeJogador());
                                if (maos2.getEsq() + maos1.getDir() > 5) {
                                    resultado2.setText(resultado.getText()); //PRINTS DE SOMA MAIOR QUE 5
                                    resultado3.setText(resultado.getText());
                                    System.out.println(maos2.getEsq() + " + " + maos1.getDir() + " = " + (maos2.getEsq() + maos1.getDir())
                                            + " - 5 = " + (maos2.getEsq() + maos1.getDir() - 5));
                                    maos2.setEsq(maos2.getEsq() + maos1.getDir() - 5);
                                    resultado4.setText("" + maos2.getEsq()); //PRINTS DE SOMA MAIOR QUE 5
                                    resultado2.setVisible(true); //HABILITANDO PRINTS DE SOMA MAIOR QUE 5
                                    maiorQue.setVisible(true);
                                    cinco.setVisible(true);
                                    resultado3.setVisible(true);
                                    menos.setText("-");
                                    menos.setVisible(true);
                                    cinco2.setText("5");
                                    cinco2.setVisible(true);
                                    igual2.setVisible(true);
                                    resultado4.setVisible(true);
                                } else {
                                    maos2.setEsq(maos2.getEsq() + maos1.getDir());
                                }
                                rodada++;
                                mao = 0;
                                cont = 0;
                                flag = false;
                                maos1.setPontos(maos1.getPontos() + maos2.getDir() + maos2.getEsq()); //AUMENTANDO A PONTUAÇÃO DO JOGADOR 1
                                maoEsq2.setImage(maos2.getMaoEsq());
                                fila.enqueue(fila.dequeue());
                                naopodeusar1.setText("Não pode selecionar estas mãos!");
                                naopodeusar2.setText("");
                                System.out.println("\nRODADA " + rodada);
                                System.out.println("\n" + maos2.getNomeJogador() + " | Pontuação: " + maos2.getPontos());
                                System.out.println("DIR: " + maos2.getDir() + " | ESQ: " + maos2.getEsq());
                                System.out.println("\nESQ: " + maos1.getEsq() + " | DIR: " + maos1.getDir());
                                System.out.println(maos1.getNomeJogador() + " | Pontuação: " + maos1.getPontos());
                            }

                        } else if (mao == 11) { //Jogador 1 fez Esq1 com Esq1
                            j1.setText("" + maos1.getEsq()); //PRINTS DE SOMA
                            j2.setText("" + maos2.getEsq());
                            resultado.setText("" + (maos1.getEsq() + maos2.getEsq()));
                            j1.setVisible(true); //HABILITANDO PRINTS EXIBINDO A SOMA QUE FOI FEITA
                            mais1.setVisible(true);
                            j2.setVisible(true);
                            igual1.setVisible(true);
                            resultado.setVisible(true);
                            selecionouMaoEsq1.setVisible(false);
                            flag = true;
                            if (cont == 130) {
                                System.out.println(maos1.getNomeJogador() + " somou sua Mão Esquerda com Mão Esquerda de " + maos2.getNomeJogador());
                                if (maos1.getEsq() + maos2.getEsq() > 5) {
                                    resultado2.setText(resultado.getText()); //PRINTS DE SOMA MAIOR QUE 5
                                    resultado3.setText(resultado.getText());
                                    System.out.println(maos1.getEsq() + " + " + maos2.getEsq() + " = " + (maos1.getEsq() + maos2.getEsq())
                                            + " - 5 = " + (maos1.getEsq() + maos2.getEsq() - 5));
                                    maos2.setEsq(maos1.getEsq() + maos2.getEsq() - 5);
                                    resultado4.setText("" + maos2.getEsq()); //PRINTS DE SOMA MAIOR QUE 5
                                    resultado2.setVisible(true); //HABILITANDO PRINTS DE SOMA MAIOR QUE 5
                                    maiorQue.setVisible(true);
                                    cinco.setVisible(true);
                                    resultado3.setVisible(true);
                                    menos.setText("-");
                                    menos.setVisible(true);
                                    cinco2.setText("5");
                                    cinco2.setVisible(true);
                                    igual2.setVisible(true);
                                    resultado4.setVisible(true);
                                } else {
                                    maos2.setEsq(maos1.getEsq() + maos2.getEsq());
                                }
                                rodada++;
                                mao = 0;
                                cont = 0;
                                flag = false;
                                maos1.setPontos(maos1.getPontos() + maos2.getDir() + maos2.getEsq()); //AUMENTANDO A PONTUAÇÃO DO JOGADOR 1
                                maoEsq2.setImage(maos2.getMaoEsq());
                                fila.enqueue(fila.dequeue());
                                naopodeusar1.setText("Não pode selecionar estas mãos!");
                                naopodeusar2.setText("");
                                System.out.println("\nRODADA " + rodada);
                                System.out.println("\n" + maos2.getNomeJogador() + " | Pontuação: " + maos2.getPontos());
                                System.out.println("DIR: " + maos2.getDir() + " | ESQ: " + maos2.getEsq());
                                System.out.println("\nESQ: " + maos1.getEsq() + " | DIR: " + maos1.getDir());
                                System.out.println(maos1.getNomeJogador() + " | Pontuação: " + maos1.getPontos());
                            }
                        }
                    } else if (fila.head().getData().equals(maos2)) { //Jogador 2 está na vez
                        j1dividirpontos.setDisable(true); //DESABLITANDO O BOTÃO DE DIVIDIR DO JOGADOR 1
                        if ((maos2.getEsq() + maos2.getDir()) % 2 == 0
                                && (maos2.getEsq() != maos2.getDir())) { //Jogador 2 pode dividir pontos
                            j2naopodedividir.setText("");
                            j2dividirpontos.setDisable(false); //HABILITA O BOTÃO PARA DIVIDIR PONTOS
                        } else { //Jogador 2 não pode dividir pontos
                            j2naopodedividir.setText("Não pode dividir pontos!");
                            j2dividirpontos.setDisable(true); //DESABILITA O BOTÃO PARA DIVIDIR PONTOS
                        }
                        if (maos2.getEsq() == 5) { //Mao Esq2 possui 5 pontos
                            maoEsq2.setVisible(false); //DESABILITANDO A MÃO QUE FOI PERDIDA
                            maoEsq2.setDisable(true);
                            maos2.setEsq(0); // SETANDO MAO ESQ2 = 0
                            perdeuMao = new Media("file:///C:/Users/DELL/Documents/NetBeansProjects/ProjetoPPJavaFx/src/Sons/farmdie.wav");
                            mpm = new MediaPlayer(perdeuMao);
                            mpm.setVolume(0.2);
                            mpm.setAutoPlay(true);
                            System.out.println(maos2.getNomeJogador() + " perdeu a mão esquerda!");
                        }
                        if (maos2.getDir() == 5) { //Mao Dir2 possui 5 pontos
                            maoDir2.setVisible(false); //DESABILITANDO A MÃO QUE FOI PERDIDA
                            maoDir2.setDisable(true);
                            maos2.setDir(0); // SETANDO MAO DIR2 = 0
                            perdeuMao = new Media("file:///C:/Users/DELL/Documents/NetBeansProjects/ProjetoPPJavaFx/src/Sons/farmdie.wav");
                            mpm = new MediaPlayer(perdeuMao);
                            mpm.setVolume(0.2);
                            mpm.setAutoPlay(true);
                            System.out.println(maos2.getNomeJogador() + " perdeu a mão direita!");
                        }
                        if (maos2.getEsq() + maos2.getDir() == 0) { // Jogador 2 não possui mais mãos
                            at.stop();
                            maoDir2.setVisible(false); //DESABILITA AS MÃOS DO JOGADOR 2
                            maoDir2.setDisable(true);
                            maoEsq2.setVisible(false);
                            maoEsq2.setDisable(true);
                            ptsj1.setText("" + maos1.getPontos());
                            ptsj2.setText("" + maos2.getPontos());
                            System.out.println("\nRODADA " + rodada);
                            System.out.println("\n" + maos2.getNomeJogador() + " | Pontuação: " + maos2.getPontos());
                            System.out.println("DIR: " + maos2.getDir() + " | ESQ: " + maos2.getEsq());
                            System.out.println("\nESQ: " + maos1.getEsq() + " | DIR: " + maos1.getDir());
                            System.out.println(maos1.getNomeJogador() + " | Pontuação: " + maos1.getPontos());
                            System.out.println(maos2.getNomeJogador() + " não tem mais mãos em jogo!");
                            System.out.println(maos1.getNomeJogador() + " é o VENCEDOR!");
                            maos1.setPontos(maos1.getPontos() + rodada);
                            ptsj1.setText("" + maos1.getPontos());
                            maos1.setVitorias(maos1.getVitorias() + 1);
                            maos2.setDerrotas(maos2.getDerrotas() + 1);
                            vitoria = new Media("file:///C:/Users/DELL/Documents/NetBeansProjects/ProjetoPPJavaFx/src/Sons/win.wav");
                            mpv = new MediaPlayer(vitoria);
                            mpv.setVolume(0.2);
                            mpv.setAutoPlay(true);
                            vezDe.setVisible(false);
                            jogadorDaVez.setVisible(false);
                            jogarNovamente.setDisable(false);
                            jogarNovamente.setVisible(true);
                            vencedor.setVisible(true);
                            nomeVencedor.setText(maos1.getNomeJogador());
                            nomeVencedor.setVisible(true);
                            System.out.println("VENCEDOR: " + maos1.getNomeJogador() + " | PONTOS: " + maos1.getPontos());
                            System.out.println("perdedor: " + maos2.getNomeJogador() + " | pontos: " + maos2.getPontos());
                            rodada = 1;
                        }
                        if (mao == 12) { // Jogador 2 fez: Esq2 com Dir1
                            j1.setText("" + maos1.getDir()); //PRINTS DE SOMA
                            j2.setText("" + maos2.getEsq());
                            resultado.setText("" + (maos1.getDir() + maos2.getEsq()));
                            j1.setVisible(true); //HABILITANDO PRINTS EXIBINDO A SOMA QUE FOI FEITA
                            mais1.setVisible(true);
                            j2.setVisible(true);
                            igual1.setVisible(true);
                            resultado.setVisible(true);
                            selecionouMaoEsq2.setVisible(false); //DESABILITANDO MÃO ESCOLHIDA
                            flag = true;
                            if (cont == 130) {
                                if (maos2.getEsq() + maos1.getDir() > 5) {
                                    resultado2.setText(resultado.getText()); //PRINTS DE SOMA MAIOR QUE 5
                                    resultado3.setText(resultado.getText());
                                    System.out.println(maos2.getEsq() + " + " + maos1.getDir() + " = " + (maos2.getEsq() + maos1.getDir())
                                            + " - 5 = " + (maos2.getEsq() + maos1.getDir() - 5));
                                    maos1.setDir(maos2.getEsq() + maos1.getDir() - 5);
                                    resultado4.setText("" + maos1.getDir()); //PRINTS DE SOMA MAIOR QUE 5
                                    resultado2.setVisible(true); //HABILITANDO PRINTS DE SOMA MAIOR QUE 5
                                    maiorQue.setVisible(true);
                                    cinco.setVisible(true);
                                    resultado3.setVisible(true);
                                    menos.setText("-");
                                    menos.setVisible(true);
                                    cinco2.setText("5");
                                    cinco2.setVisible(true);
                                    igual2.setVisible(true);
                                    resultado4.setVisible(true);
                                } else {
                                    maos1.setDir(maos2.getEsq() + maos1.getDir());
                                }
                                cont = 0;
                                flag = false;
                                mao = 0;
                                maos2.setPontos(maos2.getPontos() + maos1.getDir() + maos1.getEsq()); //AUMENTANDO A PONTUAÇÃO DO JOGADOR 2
                                maoDir1.setImage(maos1.getMaoDir());
                                fila.enqueue(fila.dequeue());
                                naopodeusar2.setText("Não pode selecionar estas mãos!");
                                naopodeusar1.setText("");
                                rodada++;
                                System.out.println("\nRODADA " + rodada);
                                System.out.println("\n" + maos2.getNomeJogador() + " | Pontuação: " + maos2.getPontos());
                                System.out.println("DIR: " + maos2.getDir() + " | ESQ: " + maos2.getEsq());
                                System.out.println("\nESQ: " + maos1.getEsq() + " | DIR: " + maos1.getDir());
                                System.out.println(maos1.getNomeJogador() + " | Pontuação: " + maos1.getPontos());
                            }
                        } else if (mao == 22) { // Jogador 2 fez: Dir2 com Dir1
                            j1.setText("" + maos1.getDir()); //PRINTS DE SOMA
                            j2.setText("" + maos2.getDir());
                            resultado.setText("" + (maos1.getDir() + maos2.getDir()));
                            j1.setVisible(true); //HABILITANDO PRINTS EXIBINDO A SOMA QUE FOI FEITA
                            mais1.setVisible(true);
                            j2.setVisible(true);
                            igual1.setVisible(true);
                            resultado.setVisible(true);
                            selecionouMaoDir2.setVisible(false); //DESABILITANDO PRINT DE MÃO ESCOLHIDA
                            flag = true;
                            if (cont == 130) {
                                System.out.println(maos2.getNomeJogador() + " somou sua Mão Direita com Mão Direita de " + maos1.getNomeJogador());
                                if (maos2.getDir() + maos1.getDir() > 5) {
                                    resultado2.setText(resultado.getText()); //PRINTS DE SOMA MAIOR QUE 5
                                    resultado3.setText(resultado.getText());
                                    System.out.println(maos2.getDir() + " + " + maos1.getDir() + " = " + (maos2.getDir() + maos1.getDir())
                                            + " - 5 = " + (maos2.getDir() + maos1.getDir() - 5));
                                    maos1.setDir(maos2.getDir() + maos1.getDir() - 5);
                                    resultado4.setText("" + maos1.getDir()); //PRINTS DE SOMA MAIOR QUE 5
                                    resultado2.setVisible(true); //HABILITANDO PRINTS DE SOMA MAIOR QUE 5
                                    maiorQue.setVisible(true);
                                    cinco.setVisible(true);
                                    resultado3.setVisible(true);
                                    menos.setText("-");
                                    menos.setVisible(true);
                                    cinco2.setText("5");
                                    cinco2.setVisible(true);
                                    igual2.setVisible(true);
                                    resultado4.setVisible(true);
                                } else {
                                    maos1.setDir(maos2.getDir() + maos1.getDir());
                                }
                                cont = 0;
                                flag = false;
                                mao = 0;
                                maos2.setPontos(maos2.getPontos() + maos1.getDir() + maos1.getEsq()); //AUMENTANDO A PONTUAÇÃO DO JOGADOR 2
                                maoDir1.setImage(maos1.getMaoDir());
                                fila.enqueue(fila.dequeue());
                                naopodeusar2.setText("Não pode selecionar estas mãos!");
                                naopodeusar1.setText("");
                                rodada++;
                                System.out.println("\nRODADA " + rodada);
                                System.out.println("\n" + maos2.getNomeJogador() + " | Pontuação: " + maos2.getPontos());
                                System.out.println("DIR: " + maos2.getDir() + " | ESQ: " + maos2.getEsq());
                                System.out.println("\nESQ: " + maos1.getEsq() + " | DIR: " + maos1.getDir());
                                System.out.println(maos1.getNomeJogador() + " | Pontuação: " + maos1.getPontos());
                            }

                        } else if (mao == 21) { //Jogador 2 fez Dir2 com Esq1
                            j1.setText("" + maos1.getEsq()); //PRINTS DE SOMA
                            j2.setText("" + maos2.getDir());
                            resultado.setText("" + (maos1.getEsq() + maos2.getDir()));
                            j1.setVisible(true); //HABILITANDO PRINTS EXIBINDO A SOMA QUE FOI FEITA
                            mais1.setVisible(true);
                            j2.setVisible(true);
                            igual1.setVisible(true);
                            resultado.setVisible(true);
                            selecionouMaoDir2.setVisible(false);
                            flag = true;
                            if (cont == 130) {
                                System.out.println(maos2.getNomeJogador() + " somou sua Mão Direita com Mão Esquerda de " + maos1.getNomeJogador());
                                if (maos1.getEsq() + maos2.getDir() > 5) {
                                    resultado2.setText(resultado.getText()); //PRINTS DE SOMA MAIOR QUE 5
                                    resultado3.setText(resultado.getText());
                                    System.out.println(maos1.getEsq() + " + " + maos2.getDir() + " = " + (maos1.getEsq() + maos2.getDir())
                                            + " - 5 = " + (maos1.getEsq() + maos2.getDir() - 5));
                                    maos1.setEsq(maos1.getEsq() + maos2.getDir() - 5);
                                    resultado4.setText("" + maos1.getEsq()); //PRINTS DE SOMA MAIOR QUE 5
                                    resultado2.setVisible(true); //HABILITANDO PRINTS DE SOMA MAIOR QUE 5
                                    maiorQue.setVisible(true);
                                    cinco.setVisible(true);
                                    resultado3.setVisible(true);
                                    menos.setText("-");
                                    menos.setVisible(true);
                                    cinco2.setText("5");
                                    cinco2.setVisible(true);
                                    igual2.setVisible(true);
                                    resultado4.setVisible(true);
                                } else {
                                    maos1.setEsq(maos1.getEsq() + maos2.getDir());
                                }
                                cont = 0;
                                flag = false;
                                mao = 0;
                                maos2.setPontos(maos2.getPontos() + maos1.getDir() + maos1.getEsq()); //AUMENTANDO A PONTUAÇÃO DO JOGADOR 2
                                maoEsq1.setImage(maos1.getMaoEsq());
                                fila.enqueue(fila.dequeue());
                                naopodeusar2.setText("Não pode selecionar estas mãos!");
                                naopodeusar1.setText("");
                                rodada++;
                                System.out.println("\nRODADA " + rodada);
                                System.out.println("\n" + maos2.getNomeJogador() + " | Pontuação: " + maos2.getPontos());
                                System.out.println("DIR: " + maos2.getDir() + " | ESQ: " + maos2.getEsq());
                                System.out.println("\nESQ: " + maos1.getEsq() + " | DIR: " + maos1.getDir());
                                System.out.println(maos1.getNomeJogador() + " | Pontuação: " + maos1.getPontos());
                            }
                        } else if (mao == 11) {//Jogador 2 fez Esq2 com Esq1
                            j1.setText("" + maos1.getEsq()); //PRINTS DE SOMA
                            j2.setText("" + maos2.getEsq());
                            resultado.setText("" + (maos1.getEsq() + maos2.getEsq()));
                            j1.setVisible(true); //HABILITANDO PRINTS EXIBINDO A SOMA QUE FOI FEITA
                            mais1.setVisible(true);
                            j2.setVisible(true);
                            igual1.setVisible(true);
                            resultado.setVisible(true);
                            selecionouMaoEsq2.setVisible(false);
                            flag = true;
                            if (cont == 130) {
                                System.out.println(maos2.getNomeJogador() + " somou sua Mão Esquerda com Mão Esquerda de " + maos1.getNomeJogador());
                                if (maos2.getEsq() + maos1.getEsq() > 5) {
                                    resultado2.setText(resultado.getText()); //PRINTS DE SOMA MAIOR QUE 5
                                    resultado3.setText(resultado.getText());
                                    System.out.println(maos2.getEsq() + " + " + maos1.getEsq() + " = " + (maos2.getEsq() + maos1.getEsq())
                                            + " - 5 = " + (maos2.getEsq() + maos1.getEsq() - 5));
                                    maos1.setEsq(maos2.getEsq() + maos1.getEsq() - 5);
                                    resultado4.setText("" + maos1.getEsq()); //PRINTS DE SOMA MAIOR QUE 5
                                    resultado2.setVisible(true); //HABILITANDO PRINTS DE SOMA MAIOR QUE 5
                                    maiorQue.setVisible(true);
                                    cinco.setVisible(true);
                                    resultado3.setVisible(true);
                                    menos.setText("-");
                                    menos.setVisible(true);
                                    cinco2.setText("5");
                                    cinco2.setVisible(true);
                                    igual2.setVisible(true);
                                    resultado4.setVisible(true);
                                } else {
                                    maos1.setEsq(maos2.getEsq() + maos1.getEsq());
                                }
                                flag = false;
                                mao = 0;
                                cont = 0;
                                maos2.setPontos(maos2.getPontos() + maos1.getDir() + maos1.getEsq()); //AUMENTANDO A PONTUAÇÃO DO JOGADOR 1
                                rodada++;
                                maoEsq1.setImage(maos1.getMaoEsq());
                                fila.enqueue(fila.dequeue());
                                naopodeusar2.setText("Não pode selecionar estas mãos!");
                                naopodeusar1.setText("");
                                System.out.println("\nRODADA " + rodada);
                                System.out.println("\n" + maos2.getNomeJogador() + " | Pontuação: " + maos2.getPontos());
                                System.out.println("DIR: " + maos2.getDir() + " | ESQ: " + maos2.getEsq());
                                System.out.println("\nESQ: " + maos1.getEsq() + " | DIR: " + maos1.getDir());
                                System.out.println(maos1.getNomeJogador() + " | Pontuação: " + maos1.getPontos());
                            }
                        }
                    }
                } catch (NullPointerException e) {
                    at.stop();
                    System.out.println("Jogo acabou.");
                }
            }

        };
        at.start();
    }

    @FXML
    public void j1SelecionouMaoDir(MouseEvent event) {
        botoes = new Media("file:///C:/Users/DELL/Documents/NetBeansProjects/ProjetoPPJavaFx/src/Sons/interface_click.wav");
        mediaPlayer = new MediaPlayer(botoes);
        mediaPlayer.setVolume(0.2);
        mediaPlayer.setAutoPlay(true);
        if (fila.head().getData().equals(maos1)) { //Jogador 1 selecionou maoDir1
            maoEsq2.setDisable(false); //HABILITA AS MÃOS DO JOGADOR 2
            maoDir2.setDisable(false);
            maoEsq1.setDisable(true); //DESABILITA AS MÃOS DO JOGADOR 1
            maoDir1.setDisable(true);
            naopodeusar1.setText("Não pode selecionar estas mãos!");
            naopodeusar2.setText("");
            selecionouMaoDir1.setVisible(true);
            mao = 20;
            j1.setVisible(false); //PRINTS EXIBINDO A SOMA QUE FOI FEITA
            mais1.setVisible(false);
            j2.setVisible(false);
            igual1.setVisible(false);
            resultado.setVisible(false);
            resultado2.setVisible(false);
            maiorQue.setVisible(false);
            cinco.setVisible(false);
            resultado3.setVisible(false);
            menos.setVisible(false);
            cinco2.setVisible(false);
            igual2.setVisible(false);
            resultado4.setVisible(false);
            System.out.println(maos1.getNomeJogador() + " selecionou Mão Direita!");
        } else { //Jogador 2 atacou maoDir1
            mao = mao + 2;
            if (mao == 12) { // Jogador 2 fez: Esq2 com Dir1
                transicao = new TranslateTransition();
                transicao.setDuration(Duration.seconds(1));
                transicao.setNode(maoEsq2);
                transicao.setToX(-380);
                transicao.setToY(0);
                transicao.setAutoReverse(true);
                transicao.setCycleCount(2);
                transicao.play();
            } else if (mao == 22) { // Jogador 2 fez: Dir2 com Dir1
                transicao = new TranslateTransition();
                transicao.setDuration(Duration.seconds(1));
                transicao.setNode(maoDir2);
                transicao.setToX(-380);
                transicao.setToY(125);
                transicao.setAutoReverse(true);
                transicao.setCycleCount(2);
                transicao.play();
            }

        }
    }

    @FXML
    public void j1SelecionouMaoEsq(MouseEvent event) {
        botoes = new Media("file:///C:/Users/DELL/Documents/NetBeansProjects/ProjetoPPJavaFx/src/Sons/interface_click.wav");
        mediaPlayer = new MediaPlayer(botoes);
        mediaPlayer.setVolume(0.2);
        mediaPlayer.setAutoPlay(true);
        if (fila.head().getData().equals(maos1)) { //Jogador 1 selecionou maoEsq1
            maoEsq2.setDisable(false); //HABILITA AS MÃOS DO JOGADOR 2
            maoDir2.setDisable(false);
            maoEsq1.setDisable(true); //DESABILITA AS MÃOS DO JOGADOR 1
            maoDir1.setDisable(true);
            naopodeusar1.setText("Não pode selecionar estas mãos!");
            naopodeusar2.setText("");
            mao = 10;
            selecionouMaoEsq1.setVisible(true);
            j1.setVisible(false); //PRINTS EXIBINDO A SOMA QUE FOI FEITA
            mais1.setVisible(false);
            j2.setVisible(false);
            igual1.setVisible(false);
            resultado.setVisible(false);
            resultado2.setVisible(false);
            maiorQue.setVisible(false);
            cinco.setVisible(false);
            resultado3.setVisible(false);
            menos.setVisible(false);
            cinco2.setVisible(false);
            igual2.setVisible(false);
            resultado4.setVisible(false);
            System.out.println(maos1.getNomeJogador() + " selecionou Mão Esquerda!");
        } else { //Jogador 2 atacou maoEsq1
            mao = mao + 1;
            if (mao == 11) { // Jogador 2 fez: Esq2 com Esq1
                transicao = new TranslateTransition();
                transicao.setDuration(Duration.seconds(1));
                transicao.setNode(maoEsq2);
                transicao.setToX(-380);
                transicao.setToY(-125);
                transicao.setAutoReverse(true);
                transicao.setCycleCount(2);
                transicao.play();
            } else if (mao == 21) { // Jogador 2 fez: Dir2 com Esq1
                transicao = new TranslateTransition();
                transicao.setDuration(Duration.seconds(1));
                transicao.setNode(maoDir2);
                transicao.setToX(-380);
                transicao.setToY(0);
                transicao.setAutoReverse(true);
                transicao.setCycleCount(2);
                transicao.play();
            }
        }
    }

    @FXML
    public void j2SelecionouMaoDir(MouseEvent event) {
        botoes = new Media("file:///C:/Users/DELL/Documents/NetBeansProjects/ProjetoPPJavaFx/src/Sons/interface_click.wav");
        mediaPlayer = new MediaPlayer(botoes);
        mediaPlayer.setVolume(0.2);
        mediaPlayer.setAutoPlay(true);
        if (fila.head().getData().equals(maos2)) { //Jogador 2 selecionou maoDir2
            maoEsq2.setDisable(true); //DESABILITA AS MÃOS DO JOGADOR 2
            maoDir2.setDisable(true);
            maoEsq1.setDisable(false); //HABILITA AS MÃOS DO JOGADOR 1
            maoDir1.setDisable(false);
            naopodeusar2.setText("Não pode selecionar estas mãos!");
            naopodeusar1.setText("");
            mao = 20;
            selecionouMaoDir2.setVisible(true);
            j1.setVisible(false); //PRINTS EXIBINDO A SOMA QUE FOI FEITA
            mais1.setVisible(false);
            j2.setVisible(false);
            igual1.setVisible(false);
            resultado.setVisible(false);
            resultado2.setVisible(false);
            maiorQue.setVisible(false);
            cinco.setVisible(false);
            resultado3.setVisible(false);
            menos.setVisible(false);
            cinco2.setVisible(false);
            igual2.setVisible(false);
            resultado4.setVisible(false);
            System.out.println(maos2.getNomeJogador() + " selecionou Mão Direita!");
        } else { // Jogador 1 atacou maoDir2
            mao = mao + 2;
            if (mao == 12) { // Jogador 1 fez: Esq1 com Dir2
                transicao = new TranslateTransition();
                transicao.setDuration(Duration.seconds(1));
                transicao.setNode(maoEsq1);
                transicao.setToX(380);
                transicao.setToY(0);
                transicao.setAutoReverse(true);
                transicao.setCycleCount(2);
                transicao.play();
            } else if (mao == 22) { // Jogador 1 fez: Dir1 com Dir2
                transicao = new TranslateTransition();
                transicao.setDuration(Duration.seconds(1));
                transicao.setNode(maoDir1);
                transicao.setToX(380);
                transicao.setToY(-125);
                transicao.setAutoReverse(true);
                transicao.setCycleCount(2);
                transicao.play();
            }
        }
    }

    @FXML
    public void j2SelecionouMaoEsq(MouseEvent event) {
        botoes = new Media("file:///C:/Users/DELL/Documents/NetBeansProjects/ProjetoPPJavaFx/src/Sons/interface_click.wav");
        mediaPlayer = new MediaPlayer(botoes);
        mediaPlayer.setVolume(0.2);
        mediaPlayer.setAutoPlay(true);
        if (fila.head().getData().equals(maos2)) { //Jogador 2 selecionou maoEsq2
            maoEsq2.setDisable(true); //DESABILITA AS MÃOS DO JOGADOR 2
            maoDir2.setDisable(true);
            maoEsq1.setDisable(false); //HABILITA AS MÃOS DO JOGADOR 1
            maoDir1.setDisable(false);
            naopodeusar2.setText("Não pode selecionar estas mãos!");
            naopodeusar1.setText("");
            mao = 10;
            selecionouMaoEsq2.setVisible(true);
            j1.setVisible(false); //PRINTS EXIBINDO A SOMA QUE FOI FEITA
            mais1.setVisible(false);
            j2.setVisible(false);
            igual1.setVisible(false);
            resultado.setVisible(false);
            resultado2.setVisible(false);
            maiorQue.setVisible(false);
            cinco.setVisible(false);
            resultado3.setVisible(false);
            menos.setVisible(false);
            cinco2.setVisible(false);
            igual2.setVisible(false);
            resultado4.setVisible(false);
            System.out.println(maos1.getNomeJogador() + " selecionou Mão Esquerda!");
        } else { //Jogador 1 atacou maoEsq2
            mao = mao + 1;
            if (mao == 11) { // Jogador 1 fez: Esq1 com Esq2
                transicao = new TranslateTransition();
                transicao.setDuration(Duration.seconds(1));
                transicao.setNode(maoEsq1);
                transicao.setToX(380);
                transicao.setToY(125);
                transicao.setAutoReverse(true);
                transicao.setCycleCount(2);
                transicao.play();
            } else if (mao == 21) { // Jogador 1 fez: Dir1 com Esq2
                transicao = new TranslateTransition();
                transicao.setDuration(Duration.seconds(1));
                transicao.setNode(maoDir1);
                transicao.setToX(380);
                transicao.setToY(0);
                transicao.setAutoReverse(true);
                transicao.setCycleCount(2);
                transicao.play();
            }
        }
    }

    @FXML
    public void j1DividiuPontos(MouseEvent event) {
        botaodividir = new Media("file:///C:/Users/DELL/Documents/NetBeansProjects/ProjetoPPJavaFx/src/Sons/jewel.wav");
        mpb = new MediaPlayer(botaodividir);
        mpb.setVolume(0.2);
        mpb.setAutoPlay(true);
        int soma = maos1.getEsq() + maos1.getDir();
        int divisao = soma / 2;
        j1.setText("" + maos1.getEsq());
        j2.setText("" + maos1.getDir());
        resultado.setText("" + soma);
        resultado3.setText("" + soma);
        menos.setText("/");
        cinco2.setText("2");
        resultado4.setText("" + divisao);
        j1.setVisible(true); //PRINTS EXIBINDO A SOMA QUE FOI FEITA
        mais1.setVisible(true);
        j2.setVisible(true);
        igual1.setVisible(true);
        resultado.setVisible(true);
        resultado2.setVisible(false);
        maiorQue.setVisible(false);
        cinco.setVisible(false);
        resultado3.setVisible(true);
        menos.setVisible(true);
        cinco2.setVisible(true);
        igual2.setVisible(true);
        resultado4.setVisible(true);

        maos1.setDir(divisao);
        maos1.setEsq(divisao);
        maoEsq1.setImage(maos1.getMaoEsq());
        maoEsq1.setVisible(true);
        maoEsq1.setDisable(false);
        maoDir1.setImage(maos1.getMaoDir());
        maoDir1.setVisible(true);
        maoDir1.setDisable(false);
        System.out.println(maos1.getNomeJogador() + " dividiu os pontos das mãos!");
        System.out.println("\n" + maos2.getNomeJogador() + " | Pontuação: " + maos2.getPontos());
        System.out.println("DIR: " + maos2.getDir() + " | ESQ: " + maos2.getEsq());
        System.out.println("\nESQ: " + maos1.getEsq() + " | DIR: " + maos1.getDir());
        System.out.println(maos1.getNomeJogador() + " | Pontuação: " + maos1.getPontos());
    }

    @FXML
    public void j2DividiuPontos(MouseEvent event) {
        botaodividir = new Media("file:///C:/Users/DELL/Documents/NetBeansProjects/ProjetoPPJavaFx/src/Sons/jewel.wav");
        mpb = new MediaPlayer(botaodividir);
        mpb.setVolume(0.2);
        mpb.setAutoPlay(true);
        int soma = maos2.getEsq() + maos2.getDir();
        int divisao = soma / 2;
        j1.setText("" + maos2.getEsq());
        j2.setText("" + maos2.getDir());
        resultado.setText("" + soma);
        resultado3.setText("" + soma);
        menos.setText("/");
        cinco2.setText("2");
        resultado4.setText("" + divisao);
        j1.setVisible(true); //PRINTS EXIBINDO A SOMA QUE FOI FEITA
        mais1.setVisible(true);
        j2.setVisible(true);
        igual1.setVisible(true);
        resultado.setVisible(true);
        resultado2.setVisible(false);
        maiorQue.setVisible(false);
        cinco.setVisible(false);
        resultado3.setVisible(true);
        menos.setVisible(true);
        cinco2.setVisible(true);
        igual2.setVisible(true);
        resultado4.setVisible(true);

        maos2.setDir(divisao);
        maos2.setEsq(divisao);
        maoEsq2.setImage(maos2.getMaoEsq());
        maoEsq2.setVisible(true);
        maoEsq2.setDisable(false);
        maoDir2.setImage(maos2.getMaoDir());
        maoDir2.setVisible(true);
        maoDir2.setDisable(false);
        System.out.println(maos2.getNomeJogador() + " dividiu os pontos das mãos!");
        System.out.println("\n" + maos2.getNomeJogador() + " | Pontuação: " + maos2.getPontos());
        System.out.println("DIR: " + maos2.getDir() + " | ESQ: " + maos2.getEsq());
        System.out.println("\nESQ: " + maos1.getEsq() + " | DIR: " + maos1.getDir());
        System.out.println(maos1.getNomeJogador() + " | Pontuação: " + maos1.getPontos());
    }

    @FXML
    public void sairDoJogo(MouseEvent event) {
        botoes = new Media("file:///C:/Users/DELL/Documents/NetBeansProjects/ProjetoPPJavaFx/src/Sons/interface_click.wav");
        mediaPlayer = new MediaPlayer(botoes);
        mediaPlayer.setVolume(0.2);
        mediaPlayer.setAutoPlay(true);
        at.stop();
        if (maos1.getVitorias() + maos2.getVitorias() > 0) { //Só grava quando alguém ganhar uma partida
            listaR.cadastrarRanking(maos1.getNomeJogador(), "Multiplayer", maos1.getPontos(), maos1.getVitorias(), maos1.getDerrotas());
            listaR.cadastrarRanking(maos2.getNomeJogador(), "Multiplayer", maos2.getPontos(), maos2.getVitorias(), maos2.getDerrotas());
            listaR.gravarListaRanking("Highscores");
        }
        while (fila.head() != null) {
            fila.dequeue();
        }
        primeiro = 0;
        System.out.println("Voltando para o menu principal");
        MainMP.stage.close();
        ProjetoPPJavaFx menu = new ProjetoPPJavaFx();
        try {
            menu.start(new Stage());
        } catch (Exception ex) {
            Logger.getLogger(FXMLMenuController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @FXML
    public void novoJogo(MouseEvent event) {
        botaodividir = new Media("file:///C:/Users/DELL/Documents/NetBeansProjects/ProjetoPPJavaFx/src/Sons/jewel.wav");
        mpb = new MediaPlayer(botaodividir);
        mpb.setVolume(0.2);
        mpb.setAutoPlay(true);
        listaR.gravarListaRanking("Highscores");
        System.out.println("Iniciando novo jogo.");
        maos1.setEsq(1);
        maos1.setDir(1);
        maoEsq1.setImage(maos1.getMaoEsq());
        maoEsq1.setVisible(true);
        maoDir1.setImage(maos1.getMaoDir());
        maoDir1.setVisible(true);
        maos2.setEsq(1);
        maos2.setDir(1);
        maoEsq2.setImage(maos2.getMaoEsq());
        maoEsq2.setVisible(true);
        maoDir2.setImage(maos2.getMaoDir());
        maoDir2.setVisible(true);
        vezDe.setVisible(true);
        jogadorDaVez.setVisible(true);
        j1.setVisible(false); //PRINTS EXIBINDO A SOMA QUE FOI FEITA
        mais1.setVisible(false);
        j2.setVisible(false);
        igual1.setVisible(false);
        resultado.setVisible(false);
        resultado2.setVisible(false);
        maiorQue.setVisible(false);
        cinco.setVisible(false);
        resultado3.setVisible(false);
        menos.setVisible(false);
        cinco2.setVisible(false);
        igual2.setVisible(false);
        resultado4.setVisible(false);
        if (primeiro == 1) {
            fila.dequeue();
            fila.dequeue();
            fila.enqueue(maos2);
            fila.enqueue(maos1);
            primeiro = 2;
        } else {
            fila.dequeue();
            fila.dequeue();
            fila.enqueue(maos1);
            fila.enqueue(maos2);
            primeiro = 1;
        }
        if (fila.head().getData().equals(maos1)) {
            maoEsq1.setDisable(false);
            maoDir1.setDisable(false);
            maoEsq2.setDisable(true);
            maoDir2.setDisable(true);
        } else {
            maoEsq1.setDisable(true);
            maoDir1.setDisable(true);
            maoEsq2.setDisable(false);
            maoDir2.setDisable(false);
        }
        initialize(url2, rb2);
    }
}
