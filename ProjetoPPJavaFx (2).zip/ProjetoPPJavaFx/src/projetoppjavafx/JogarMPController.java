/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetoppjavafx;

import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import pacoteJogo.Fila;
import pacoteJogo.Maos;

public class JogarMPController {

    @FXML
    private ImageView fundo1;

    @FXML
    private ImageView fundo2;

    @FXML
    private ImageView logoCatolica;

    @FXML
    private Text titulo1;

    @FXML
    private Text titulo2;

    @FXML
    private Text autor;

    @FXML
    private TextField nomeJogador1;

    @FXML
    private TextField nomeJogador2;

    @FXML
    private Button botaoAvancar;

    @FXML
    private Button botaoVoltar;

    @FXML
    private RadioButton botaoJ1Comeca;

    @FXML
    private ToggleGroup grupo;

    @FXML
    private RadioButton botaoJ2Comeca;

    @FXML
    private Button confirmaNome1;

    @FXML
    private Button confirmaNome2;

    @FXML
    private Button confirmaOrdem;

    @FXML
    private Label naotemnome;

    @FXML
    private Label naotemordem;

    @FXML
    private Label jogador1branco;

    @FXML
    private Label jogador2branco;

    private Media botoes;
    private MediaPlayer mediaPlayer;

    public static Maos maos1, maos2;
    public static int primeiro = 0;
    public static Fila fila;

    @FXML
    public void confirmandoOrdem(ActionEvent event) {
        botoes = new Media("file:///C:/Users/DELL/Documents/NetBeansProjects/ProjetoPPJavaFx/src/Sons/interface_click.wav");
        mediaPlayer = new MediaPlayer(botoes);
        mediaPlayer.setVolume(0.2);
        mediaPlayer.setAutoPlay(true);
        RadioButton ordem = (RadioButton) grupo.getSelectedToggle();
        if (ordem.getText().equals("JOGADOR 1")) {
            System.out.println(nomeJogador1.getText() + " é o primeiro a jogar");
            primeiro = 1;
            naotemordem.setText("");
        } else if (ordem.getText().equals("JOGADOR 2")) {
            System.out.println(nomeJogador2.getText() + " é o primeiro a jogar");
            primeiro = 2;
            naotemordem.setText("");
        }

    }

    @FXML
    public void voltando(ActionEvent event) {
        botoes = new Media("file:///C:/Users/DELL/Documents/NetBeansProjects/ProjetoPPJavaFx/src/Sons/interface_click.wav");
        mediaPlayer = new MediaPlayer(botoes);
        mediaPlayer.setVolume(0.2);
        mediaPlayer.setAutoPlay(true);
        primeiro = 0;
        System.out.println("Voltando ao Menu Principal");
        MainJogarMP.stage.close();
        ProjetoPPJavaFx menu = new ProjetoPPJavaFx();
        try {
            menu.start(new Stage());
        } catch (Exception ex) {
            Logger.getLogger(FXMLMenuController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @FXML
    public void avancando(ActionEvent event) {
        if (nomeJogador1.getText().contains(" ") || nomeJogador1.getText().equals("")) {
            botoes = new Media("file:///C:/Users/DELL/Documents/NetBeansProjects/ProjetoPPJavaFx/src/Sons/jewel.wav");
            mediaPlayer = new MediaPlayer(botoes);
            mediaPlayer.setVolume(0.2);
            mediaPlayer.setAutoPlay(true);
            System.out.println("Nome do Jogador 1 possui espaço em branco.");
            naotemnome.setText("Nome do Jogador 1 possui espaço em branco.");
        } else if (nomeJogador2.getText().contains(" ") || nomeJogador2.getText().equals("")) {
            botoes = new Media("file:///C:/Users/DELL/Documents/NetBeansProjects/ProjetoPPJavaFx/src/Sons/jewel.wav");
            mediaPlayer = new MediaPlayer(botoes);
            mediaPlayer.setVolume(0.2);
            mediaPlayer.setAutoPlay(true);
            System.out.println("Nome do Jogador 2 possui espaço em branco.");
            naotemnome.setText("Nome do Jogador 2 possui espaço em branco.");
        } else if (nomeJogador1.getText().length() > 30) {
            botoes = new Media("file:///C:/Users/DELL/Documents/NetBeansProjects/ProjetoPPJavaFx/src/Sons/jewel.wav");
            mediaPlayer = new MediaPlayer(botoes);
            mediaPlayer.setVolume(0.2);
            mediaPlayer.setAutoPlay(true);
            System.out.println("Nome do Jogador 1 possui mais de 30 caracteres.");
            naotemnome.setText("Nome do Jogador 1 possui mais de 30 caracteres.");
        } else if (nomeJogador2.getText().length() > 30) {
            botoes = new Media("file:///C:/Users/DELL/Documents/NetBeansProjects/ProjetoPPJavaFx/src/Sons/jewel.wav");
            mediaPlayer = new MediaPlayer(botoes);
            mediaPlayer.setVolume(0.2);
            mediaPlayer.setAutoPlay(true);
            System.out.println("Nome do Jogador 2 possui mais de 30 caracteres.");
            naotemnome.setText("Nome do Jogador 2 possui mais de 30 caracteres.");
        } else if (nomeJogador1.getText().equals(nomeJogador2.getText())) {
            botoes = new Media("file:///C:/Users/DELL/Documents/NetBeansProjects/ProjetoPPJavaFx/src/Sons/jewel.wav");
            mediaPlayer = new MediaPlayer(botoes);
            mediaPlayer.setVolume(0.2);
            mediaPlayer.setAutoPlay(true);
            System.out.println("Não podem ter nomes iguais.");
            naotemnome.setText("Não podem ter nomes iguais.");
        } else if (primeiro == 0) {
            botoes = new Media("file:///C:/Users/DELL/Documents/NetBeansProjects/ProjetoPPJavaFx/src/Sons/jewel.wav");
            mediaPlayer = new MediaPlayer(botoes);
            mediaPlayer.setVolume(0.2);
            mediaPlayer.setAutoPlay(true);
            System.out.println("Não foi escolhido quem começerá o jogo.");
            naotemnome.setText("Não foi escolhido quem começerá o jogo.");
        } else {
            botoes = new Media("file:///C:/Users/DELL/Documents/NetBeansProjects/ProjetoPPJavaFx/src/Sons/bigbutton.wav");
            mediaPlayer = new MediaPlayer(botoes);
            mediaPlayer.setVolume(0.2);
            mediaPlayer.setAutoPlay(true);
            naotemnome.setText("");
            maos1 = new Maos();
            maos1.setNomeJogador(nomeJogador1.getText());
            maos2 = new Maos();
            maos2.setNomeJogador(nomeJogador2.getText());
            fila = new Fila();
            if (primeiro == 1) {
                fila.enqueue(maos1);
                fila.enqueue(maos2);
            } else {
                fila.enqueue(maos2);
                fila.enqueue(maos1);
            }
            System.out.println("Entrando no jogo MP");
            MainJogarMP.stage.close();
            MainMP menu = new MainMP();
            try {
                menu.start(new Stage());
            } catch (Exception ex) {
                Logger.getLogger(FXMLMenuController.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

    }

}
