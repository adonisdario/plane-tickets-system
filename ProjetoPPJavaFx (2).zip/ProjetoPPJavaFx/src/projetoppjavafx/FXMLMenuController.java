/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetoppjavafx;

import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.text.Text;
import javafx.stage.Stage;

/**
 *
 * @author DELL
 */
public class FXMLMenuController {

    @FXML
    private AnchorPane telaMenu;

    @FXML
    private ImageView fundo1;

    @FXML
    private ImageView fundo2;

    @FXML
    private ImageView logoCatolica;

    @FXML
    private Text titulo1;

    @FXML
    private Text titulo2;

    @FXML
    private Button botaoSair;

    @FXML
    private Button botaoRanking;

    @FXML
    private Button botaoRegras;

    @FXML
    private Button botaoJogar;

    @FXML
    private Text autor;

    private Media botoes;
    private MediaPlayer mediaPlayer;

    @FXML
    public void entrandoJogar(MouseEvent event) {
        botoes = new Media("file:///C:/Users/DELL/Documents/NetBeansProjects/ProjetoPPJavaFx/src/Sons/interface_click.wav");
        mediaPlayer = new MediaPlayer(botoes);
        mediaPlayer.setVolume(0.2);
        mediaPlayer.setAutoPlay(true);
        System.out.println("Entrando na tela inicial jogo.");
        ProjetoPPJavaFx.stage.close();
        MainJogarMP menuJogo = new MainJogarMP();
        try {
            menuJogo.start(new Stage());
        } catch (Exception ex) {
            Logger.getLogger(FXMLMenuController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @FXML
    public void entrandoRanking(MouseEvent event) {
        botoes = new Media("file:///C:/Users/DELL/Documents/NetBeansProjects/ProjetoPPJavaFx/src/Sons/interface_click.wav");
        mediaPlayer = new MediaPlayer(botoes);
        mediaPlayer.setVolume(0.2);
        mediaPlayer.setAutoPlay(true);
        System.out.println("Entrando no ranking");
        ProjetoPPJavaFx.stage.close();
        MainRanking menuRanking = new MainRanking();
        try {
            menuRanking.start(new Stage());
        } catch (Exception ex) {
            Logger.getLogger(FXMLMenuController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @FXML
    public void entrandoRegras(MouseEvent event) {
        botoes = new Media("file:///C:/Users/DELL/Documents/NetBeansProjects/ProjetoPPJavaFx/src/Sons/interface_click.wav");
        mediaPlayer = new MediaPlayer(botoes);
        mediaPlayer.setVolume(0.2);
        mediaPlayer.setAutoPlay(true);
        System.out.println("Entrando nas regras");
        ProjetoPPJavaFx.stage.close();
        MainRegras menuRegras = new MainRegras();
        try {
            menuRegras.start(new Stage());
        } catch (Exception ex) {
            Logger.getLogger(FXMLMenuController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @FXML
    public void sairDoJogo(MouseEvent event) {
        botoes = new Media("file:///C:/Users/DELL/Documents/NetBeansProjects/ProjetoPPJavaFx/src/Sons/interface_click.wav");
        mediaPlayer = new MediaPlayer(botoes);
        mediaPlayer.setVolume(0.2);
        mediaPlayer.setAutoPlay(true);
        System.out.println("Saindo do jogo.");
        ProjetoPPJavaFx.stage.close();
    }

}
