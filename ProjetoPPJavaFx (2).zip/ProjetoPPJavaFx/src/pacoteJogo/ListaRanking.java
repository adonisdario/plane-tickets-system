package pacoteJogo;

public class ListaRanking {

    public NodeRanking first;
    private NodeRanking last;
    private int qtd;

    public boolean isFull(String categoria) {
        if (qtd == 10) {
            return true;
        }
        return false;
    }

    public void cadastrarRanking(String nomeJogador, String categoria, int pontuacao, int vitorias, int derrotas) {
        NodeRanking aux, aux2, novo;
        Ranking ranking;
        if (first == null) {
            ranking = new Ranking(nomeJogador);
            ranking.setCategoria(categoria);
            ranking.setVitorias(vitorias);
            ranking.setDerrotas(derrotas);
            ranking.setMaxPont(pontuacao);
            novo = new NodeRanking(ranking);
            first = novo;
            last = novo;
            qtd++;
            System.out.println("1a Pontuação gravada.");
        } else if (pontuacao >= first.getData().getMaxPont()) {
            if (isFull(categoria)) {
                removerUltimoRanking(categoria);
            }
            ranking = new Ranking(nomeJogador);
            ranking.setCategoria(categoria);
            ranking.setVitorias(vitorias);
            ranking.setDerrotas(derrotas);
            ranking.setMaxPont(pontuacao);
            novo = new NodeRanking(ranking);
            novo.setNext(first);
            first.setPrev(novo);
            first = novo;
            qtd++;
            System.out.println("Maior Pontuação gravada.");
        } else if (pontuacao <= last.getData().getMaxPont()) {
            if (isFull(categoria)) {
                removerUltimoRanking(categoria);
            }
            ranking = new Ranking(nomeJogador);
            ranking.setCategoria(categoria);
            ranking.setVitorias(vitorias);
            ranking.setDerrotas(derrotas);
            ranking.setMaxPont(pontuacao);
            novo = new NodeRanking(ranking);
            last.setNext(novo);
            novo.setPrev(last);
            last = novo;
            qtd++;
            System.out.println("Pior Pontuação gravada.");
        } else {
            aux = first.getNext();
            while (aux != null) {
                if (pontuacao > aux.getData().getMaxPont()) {
                    if (isFull(categoria)) {
                        removerUltimoRanking(categoria);
                    }
                    ranking = new Ranking(nomeJogador);
                    ranking.setCategoria(categoria);
                    ranking.setVitorias(vitorias);
                    ranking.setDerrotas(derrotas);
                    ranking.setMaxPont(pontuacao);
                    novo = new NodeRanking(ranking);
                    aux2 = aux.getPrev();
                    novo.setPrev(aux2);
                    novo.setNext(aux);
                    aux2.setNext(novo);
                    aux.setPrev(novo);
                    qtd++;
                    System.out.println("Pontuação gravada.");
                    return;
                } else if (pontuacao == aux.getData().getMaxPont()) {
                    if (vitorias > aux.getData().getMaxPont()) {
                        if (isFull(categoria)) {
                            removerUltimoRanking(categoria);
                        }
                        ranking = new Ranking(nomeJogador);
                        ranking.setCategoria(categoria);
                        ranking.setVitorias(vitorias);
                        ranking.setDerrotas(derrotas);
                        ranking.setMaxPont(pontuacao);
                        novo = new NodeRanking(ranking);
                        aux2 = aux.getPrev();
                        novo.setPrev(aux2);
                        novo.setNext(aux);
                        aux2.setNext(novo);
                        aux.setPrev(novo);
                        qtd++;
                        System.out.println("Pontuação gravada.");
                        return;
                    } else if (vitorias == aux.getData().getVitorias()) {
                        if (derrotas <= aux.getData().getDerrotas()) {
                            if (isFull(categoria)) {
                                removerUltimoRanking(categoria);
                            }
                            ranking = new Ranking(nomeJogador);
                            ranking.setCategoria(categoria);
                            ranking.setVitorias(vitorias);
                            ranking.setDerrotas(derrotas);
                            ranking.setMaxPont(pontuacao);
                            novo = new NodeRanking(ranking);
                            aux2 = aux.getPrev();
                            novo.setPrev(aux2);
                            novo.setNext(aux);
                            aux2.setNext(novo);
                            aux.setPrev(novo);
                            qtd++;
                            System.out.println("Pontuação gravada.");
                            return;
                        }
                    }

                }
                aux = aux.getNext();
            }
        }
    }

    public void exibirMultiplayer() {
        int cont = 1;
        NodeRanking aux = first;
        if (first == null) {
            System.out.println("Nenhuma pontuação registrada.");
            return;
        } else {
            System.out.println("\n++++++ MULTIPLAYER ++++++");
            while (aux != null) {
                if (aux.getData().getCategoria().equals("Multiplayer")) {
                    System.out.println(cont + "º: " + aux.getData());
                    cont++;
                }
                aux = aux.getNext();
            }
        }
        if (cont == 0) {
            System.out.println("Nenhuma pontuação desta categoria registrada.");
        }
    }

    public void removerUltimoRanking(String categoria) { //Remove o cliente da lista.
        NodeRanking aux = first;
        if (first == null) {
            System.out.println("Lista Vazia.");
        } else {
            while (aux != null) {
                if (aux == last) {
                    last.setNext(null);
                    last = last.getPrev();
                    qtd--;
                }
                aux = aux.getNext();
            }
            System.out.println("Ranking removido do cadastro.");
        }

    }

    public void reinserirListaRanking(Ranking r) {
        NodeRanking novo = new NodeRanking(r);

        if (this.first == null) {
            this.first = novo;
            this.last = novo;
            qtd++;
        } else {
            this.last.setNext(novo);
            novo.setPrev(this.last);
            this.last = novo;
            qtd++;
        }
    } //OK

    public void gravarListaRanking(String nomeArq) { // Da lista para o arquivo
        NodeRanking aux = this.first;

        if (this.first == null) {
            ArquivoBinarioRanking arq = new ArquivoBinarioRanking();
            arq.openToWrite("Highscores");
            arq.gravarRanking(null);
            arq.closeWriteFile();
        } else {
            ArquivoBinarioRanking arq = new ArquivoBinarioRanking();
            arq.openToWrite("Highscores");
            while (aux != null) {
                arq.gravarRanking(aux.getData());
                aux = aux.getNext();
            }
            arq.closeWriteFile();
        }
    } //OK

    public void carregarListaRanking(String nomeArq) { // Do arquivo para a lista
        ArquivoBinarioRanking arq = new ArquivoBinarioRanking();
        Ranking r;

        boolean exists = arq.openToRead("Highscores");
        if (exists == true) {
            r = arq.lerRanking();
            while (r != null) {
                this.reinserirListaRanking(r);
                r = arq.lerRanking();
            }
            arq.closeReadFile();
            System.out.println("Arquivo Ranking aberto.");
        } else {
            arq.openToWrite("Highscores");
            arq.closeWriteFile();
            System.out.println("Arquivo Ranking criado.");
        }
    }
}
