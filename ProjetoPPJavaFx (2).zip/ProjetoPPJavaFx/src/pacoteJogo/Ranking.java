package pacoteJogo;

import java.io.Serializable;

public class Ranking implements Serializable {
    private final String nomeJogador;
    private int maxPont, vitorias, derrotas;
    private String categoria;//Fácil, Difícil, Multiplayer

    public Ranking(String nomeJogador) {
        this.nomeJogador = nomeJogador;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public String getNomeJogador() {
        return nomeJogador;
    }

    public int getMaxPont() {
        return maxPont;
    }

    public void setMaxPont(int maxPont) {
        this.maxPont = maxPont;
    }

    public int getVitorias() {
        return vitorias;
    }

    public void setVitorias(int vitorias) {
        this.vitorias = vitorias;
    }

    public int getDerrotas() {
        return derrotas;
    }

    public void setDerrotas(int derrotas) {
        this.derrotas = derrotas;
    }

    @Override
    public String toString() {
        return "Nome: " + nomeJogador + ", " + maxPont + " Pontos, " + vitorias + " Vitórias, " + derrotas + " Derrotas.";
    }
    
    
}
