package pacoteJogo;

import javafx.scene.image.Image;

public class Maos {

    private int esq, dir, pontos, vitorias, derrotas;
    private String nomeJogador;
    private Image maoEsq, maoDir;

    public Maos() {
        esq = 1;
        dir = 1;
        vitorias = 0;
        derrotas = 0;
    }

    public Image getMaoEsq() {
        switch (getEsq()) {
            case 1:
                maoEsq = new Image("/Imagens Projeto/Slide2.png");
                break;
            case 2:
                maoEsq = new Image("/Imagens Projeto/Slide4.png");
                break;
            case 3:
                maoEsq = new Image("/Imagens Projeto/Slide6.png");
                break;
            case 4:
                maoEsq = new Image("/Imagens Projeto/Slide8.png");
                break;
            case 5:
                maoEsq = new Image("/Imagens Projeto/Slide10.png");
                break;
            default:
                break;
        }
        return maoEsq;
    }

    public void setMaoEsq(Image maoEsq) {
        this.maoEsq = maoEsq;
    }

    public Image getMaoDir() {
        switch (getDir()) {
            case 1:
                maoDir = new Image("/Imagens Projeto/Slide1.png");
                break;
            case 2:
                maoDir = new Image("/Imagens Projeto/Slide3.png");
                break;
            case 3:
                maoDir = new Image("/Imagens Projeto/Slide5.png");
                break;
            case 4:
                maoDir = new Image("/Imagens Projeto/Slide7.png");
                break;
            case 5:
                maoDir = new Image("/Imagens Projeto/Slide9.png");
                break;
            default:
                break;
        }
        return maoDir;
    }

    public void setMaoDir(Image maoDir) {
        this.maoDir = maoDir;
    }

    public int getEsq() {
        return esq;
    }

    public void setEsq(int esq) {
        this.esq = esq;
    }

    public int getDir() {
        return dir;
    }

    public void setDir(int dir) {
        this.dir = dir;
    }

    public String getNomeJogador() {
        return nomeJogador;
    }

    public void setNomeJogador(String nomeJogador) {
        this.nomeJogador = nomeJogador;
    }

    public int getPontos() {
        return pontos;
    }

    public void setPontos(int pontos) {
        this.pontos = pontos;
    }

    public int getVitorias() {
        return vitorias;
    }

    public void setVitorias(int vitorias) {
        this.vitorias = vitorias;
    }

    public int getDerrotas() {
        return derrotas;
    }

    public void setDerrotas(int derrotas) {
        this.derrotas = derrotas;
    }

}
