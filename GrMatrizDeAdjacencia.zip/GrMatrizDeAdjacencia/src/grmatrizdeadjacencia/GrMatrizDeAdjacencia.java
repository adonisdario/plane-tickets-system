package grmatrizdeadjacencia;

public class GrMatrizDeAdjacencia {

    public static void main(String[] args) {
        int vertices, n, i, j;

        String mat[][];
        ArquivoTexto arq = new ArquivoTexto();
        arq.openToRead("grafo");
        String[] texto2 = new String[10];
        n = arq.lerDados(texto2);
        vertices = Integer.parseInt(texto2[0]); //pega o número de vertices do grafo
        String letras[];
        mat = new String[vertices][vertices];
        letras = new String[vertices];

        for (i = 0; i < mat.length; i++) { //Constroi o desenho do Grafo

            for (j = 0; j < mat.length; j++) {
                mat[i][j] = "0";
            }

        }

        for (i = 0; i < n; i++) { //percorrendo o arquivo
            j = 0;
            if (i > 0) {
                letras[i - 1] = "" + texto2[i].charAt(0);
                try {
                    while (i > 0 && !Character.isSpaceChar(texto2[i].charAt(j))) {
                        if (!Character.isLetter(texto2[i].charAt(j))) {
                            mat[i - 1][Integer.parseInt("" + texto2[i].charAt(j))] = "1";
                        }
                        j = j + 2;
                    }
                } catch (StringIndexOutOfBoundsException e) {
                }
            }
        }
        System.out.println("\nGRAFO:");
        System.out.print("   ");
        for (i = 0; i < letras.length; i++) {
            System.out.print("[" + letras[i] + "] ");
        }
        System.out.println("");

        for (i = 0; i < mat.length; i++) { //Constroi o desenho do Grafo
            System.out.print("[" + letras[i] + "] ");
            for (j = 0; j < mat.length; j++) {
                System.out.print(" " + mat[i][j] + "  ");
            }
            System.out.println("");
        }

        arq.closeReadFile();
    }

}
