package buscaemextensao;

import java.util.Scanner;

public class BuscaEmExtensao {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int vertices, n, i, j;
        Lista[] grafo;
        ArquivoTexto arq = new ArquivoTexto();
        arq.openToRead("grafo");
        String[] texto2 = new String[10];
        n = arq.lerDados(texto2);
        vertices = Integer.parseInt(texto2[0]); //pega o número de vertices do grafo
        String[] nomesVertices;
        grafo = new Lista[vertices];
        nomesVertices = new String[vertices + 1];

        for (i = 0; i < n; i++) { //percorrendo o arquivo
            j = 0;
            if (i > 0) {
                nomesVertices[i - 1] = "" + texto2[i].charAt(0);
                System.out.println("Vértice : " + nomesVertices[i - 1]);
                grafo[i - 1] = new Lista();
                grafo[i - 1].exibir(nomesVertices[i - 1]);
                try {
                    while (i > 0 && !Character.isSpaceChar(texto2[i].charAt(j))) {
                        if (!Character.isLetter(texto2[i].charAt(j))) {
                            grafo[i - 1].adicionar("" + texto2[i].charAt(j), "" + texto2[i].charAt(0));
                            grafo[i - 1].exibir(nomesVertices[i - 1]);
                        }
                        j = j + 2;
                    }
                } catch (StringIndexOutOfBoundsException e) {
                }
            }
        }
        System.out.println("\nGRAFO:");

        for (i = 0; i < grafo.length; i++) { //Constroi o desenho do Grafo
            grafo[i].exibir(nomesVertices[i]);
        }

        System.out.print("Digite o nome vértice de start: ");
        String s = in.nextLine();
        int iStart;

        for (i = 0; i < nomesVertices.length; i++) {
            if (s.compareTo(nomesVertices[i]) == 0) {
                iStart = i;
                break;
            }
        }

        buscaEmExtensao(grafo, s, i - 1, vertices, nomesVertices);

        arq.closeReadFile();
    }

    public static void buscaEmExtensao(Lista grafo[], String s, int iStart, int vertices, String nomesVertices[]) {
        Fila fila = new Fila();
        String letras[], cor[], aux;
        int d[], ant[], u, v;
        cor = new String[vertices];
        d = new int[vertices];
        ant = new int[vertices];
        for (u = 0; u < grafo.length; u++) {
            cor[u] = "BRANCO";
            d[u] = Integer.MIN_VALUE;
            ant[u] = -1;
        }
        d[iStart] = 0;
        cor[iStart] = "CINZA";
        fila.enqueue(s);
        while (!fila.isEmpty()) {
            aux = fila.dequeue();
            for (int i = 0; i < nomesVertices.length; i++) {
                if (aux.compareTo(nomesVertices[i]) == 0) {
                    u = i-1;
                    break;
                }
            }
            for (v = 0; v < grafo.length; v++) {
                if (cor[v] == "BRANCO") {
                    cor[v] = "CINZA";
                    d[v] = d[u] + 1;
                    ant[v] = u;
                    fila.enqueue(s);
                }
            }
            cor[u] = "PRETO";
        }
    }
    
    
}
