package buscaemextensao;

public class Lista {

    private Node first, last;
    private int qtd;

    public void adicionar(String vertice, String antecessor) {
        Node novo, aux1 = first, aux2 = aux1;
        if (first == null) {
            first = new Node();
            first.setVertice(vertice);
            first.setAntecessor(antecessor);
            last = first;
            qtd = 1;
        } else if (vertice.compareToIgnoreCase(first.getVertice()) <= 0) {
            novo = new Node();
            novo.setVertice(vertice);
            novo.setAntecessor(antecessor);
            novo.setNext(first);
            first = novo;
            qtd++;
        } else if (vertice.compareToIgnoreCase(last.getVertice()) >= 0) {
            novo = new Node();
            novo.setVertice(vertice);
            novo.setAntecessor(antecessor);
            last.setNext(novo);
            last = novo;
            qtd++;
        } else {
            while (aux1 != null) {
                if (vertice.compareToIgnoreCase(aux1.getVertice()) < 0) {
                    novo = new Node();
                    novo.setVertice(vertice);
                    novo.setAntecessor(antecessor);
                    novo.setNext(aux1);
                    aux2.setNext(novo);
                    qtd++;
                    break;
                }
                aux2 = aux1;
                aux1 = aux1.getNext();
            }
        }
    }
    
    public void exibir(String antecessor) {
        Node aux = first;
        System.out.print("[" + antecessor + "] -> ");
        if (aux == null) {
            System.out.println("NULL");
            return;
        }
        
        while (aux != null) {
            System.out.print(aux.getVertice() + " -> ");
            aux = aux.getNext();
        }
        System.out.println("NULL");
    }
}
